package personPackage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.Scanner;

public class Person implements Serializable
{

	private String firstName;
	private String lastName;
	private String phoneNumber;
	private Address address;
	private String id;
	private static int idNum = 0;

	public Person(String firstName, String lastName, String phoneNumber, Address address) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.address = address;
		File idFile = new File("IDNum.txt");
		try {
			Scanner input = new Scanner(idFile);
			idNum = input.nextInt();

		} catch (FileNotFoundException e1) {

		}

		this.id = String.valueOf(idNum++);

		for (int j = id.length(); j < 8; j++) {
			if (j == 7) {
				id = "P" + id;
				break;
			}
			id = "0" + id;
		}

		PrintWriter pw;
		try {
			pw = new PrintWriter("IDNum.txt");
			pw.print(idNum);
			pw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public static int getIdNum() {
		return idNum;
	}

	public static void setIdNum(int idNum) {
		Person.idNum = idNum;
	}

	public String getId() {
		return id;
	}

	@Override
	public String toString() {
		return "\nName: " + firstName + " " + lastName + "\nPhone Number: " + phoneNumber
				+ "\n" + address.toString() + "\nID: " + id+"\n";
	}

}
