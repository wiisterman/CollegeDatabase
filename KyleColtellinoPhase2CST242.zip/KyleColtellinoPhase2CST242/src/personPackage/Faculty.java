package personPackage;

import java.io.Serializable;
import java.util.ArrayList;

import coursePackage.Course;

public class Faculty extends Person implements Serializable
{

	private String rank;
	private double salary;
	private ArrayList<Course> coursesTeaching;
	public Faculty(String firstName, String lastName, String phoneNumber, Address address, String rank, double salary,
			ArrayList<Course> coursesTeaching) {
		super(firstName, lastName, phoneNumber, address);
		this.rank = rank;
		this.salary = salary;
		this.coursesTeaching = coursesTeaching;
	}
	public String getRank() {
		return rank;
	}
	public void setRank(String rank) {
		this.rank = rank;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public ArrayList<Course> getCoursesTeaching() {
		return coursesTeaching;
	}
	public void setCoursesTeaching(ArrayList<Course> coursesTeaching) {
		this.coursesTeaching = coursesTeaching;
	}
	@Override
	public String toString() {
		return "Faculty\n" + super.toString() + "Rank: " + rank + "\nSalary: $" + salary
				+ "\nCourses Teaching: " + coursesTeaching.toString() + "\n";
	}
	
	
}
