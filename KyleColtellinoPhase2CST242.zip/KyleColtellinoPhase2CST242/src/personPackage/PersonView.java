package personPackage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import coursePackage.Course;
import coursePackage.CoursePane;
import coursePackage.MasterCourseBag;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import textBookPackage.Author;
import textBookPackage.MasterBookBag;
import textBookPackage.TextBook;
import textBookPackage.TextBookPane;

public class PersonView extends Application {

	private String major = "";
	private String nv = "";
	private String ov = "";
	private String stateString = "";
	private ArrayList<Course> coursesTakingArray;
	private ArrayList<Course> coursesTookArray;
	private ArrayList<String> coursesTakingArrayString;
	private ArrayList<String> coursesTookArrayString;
	private ArrayList<Course> coursesNeededArray;
	private ArrayList<String> coursesNeededStringArray;
	private BorderPane rootBorderPane;
	private MenuBar menuBar;
	private Menu fileMenu;

	private Menu importItem;
	private MenuItem importStudentItem;
	private MenuItem importFacultyItem;
	private MenuItem importCourseItem;
	private MenuItem importTextBookItem;

	private Menu exportItem;
	private MenuItem exportStudentItem;
	private MenuItem exportFacultyItem;
	private MenuItem exportCourseItem;
	private MenuItem exportTextBookItem;

	private MenuItem saveItem;
	private MenuItem loadItem;
	private MenuItem exitItem;

	private Menu insertMenu;
	private MenuItem insertStudentItem;
	private MenuItem insertFacultyItem;
	private MenuItem insertCourseItem;
	private MenuItem insertTextBookItem;

	private Menu searchMenu;
	private MenuItem searchStudentItem;
	private MenuItem searchFacultyItem;
	private MenuItem searchCourseItem;
	private MenuItem searchTextBookItem;

	private Menu removeMenu;
	private MenuItem removeStudentItem;
	private MenuItem removeFacultyItem;
	private MenuItem removeCourseItem;
	private MenuItem removeTextBookItem;

	private Menu updateMenu;
	private MenuItem updateStudentItem;
	private MenuItem updateFacultyItem;
	private MenuItem updateCourseItem;
	private MenuItem updateTextBookItem;

	private Menu displayMenu;
	private MenuItem displayStudentItem;
	private MenuItem displayFacultyItem;
	private MenuItem displayCourseItem;
	private MenuItem displayTextBookItem;

	private VBox contentsBox;
	private HBox buttonsBox;
	private BodyBag studentBag;
	private BodyBag facultyBag;
	private PersonPane root;
	private CoursePane courseRoot;
	private TextBookPane textBookRoot;
	private MasterBookBag textBookBag;
	private MasterCourseBag courseBag;
	private ArrayList<Author> author;
	private ArrayList<TextBook> textBookArray;
	private ArrayList<Course> courseArray;
	private Course defaultCourse;
	private Faculty defaultFaculty;
	private Student defaultStudent;
	private String studentFile;
	private String facultyFile;
	private String courseFile;
	private String textBookFile;
	private double creditsTakingInt;
	Course testCourse;

	@Override
	public void start(Stage primaryStage) throws Exception {
		studentBag = new BodyBag();
		courseBag = new MasterCourseBag();
		textBookBag = new MasterBookBag();
		facultyBag = new BodyBag();
		facultyBag.loadF();
		studentBag.loadS();
		courseBag.load();
		textBookBag.load();
		primaryStage.setTitle("Database");
		studentFile = "";
		facultyFile = "";
		courseFile = "";
		textBookFile = "";
		
		root = new PersonPane();
		courseRoot = new CoursePane();
		textBookRoot = new TextBookPane();
		textBookArray = new ArrayList<TextBook>();

		creditsTakingInt = 0;

		author = new ArrayList<Author>();
		coursesTakingArray = new ArrayList<Course>();
		coursesTookArray = new ArrayList<Course>();
		coursesNeededArray = new ArrayList<Course>();
		coursesTakingArrayString = new ArrayList<String>();
		coursesTookArrayString = new ArrayList<String>();

		rootBorderPane = new BorderPane();
		menuBar = new MenuBar();
		contentsBox = new VBox(10);
		contentsBox.setPadding(new Insets(10));
		buttonsBox = new HBox(10);
		buttonsBox.setPadding(new Insets(10));
		fileMenu = new Menu("File");

		importItem = new Menu("Import");
		importStudentItem = new MenuItem("Import Student");
		importFacultyItem = new MenuItem("Import Faculty");
		importCourseItem = new MenuItem("Import Course");
		importTextBookItem = new MenuItem("Import TextBook");
		importItem.getItems().addAll(importStudentItem, importFacultyItem, importCourseItem, importTextBookItem);

		exportItem = new Menu("Export");
		exportStudentItem = new MenuItem("Export Student");
		exportFacultyItem = new MenuItem("Export Faculty");
		exportCourseItem = new MenuItem("Export Course");
		exportTextBookItem = new MenuItem("Export TextBook");
		exportItem.getItems().addAll(exportStudentItem, exportFacultyItem, exportCourseItem, exportTextBookItem);

		saveItem = new MenuItem("Save");
		loadItem = new MenuItem("Load");
		exitItem = new MenuItem("Exit");

		searchMenu = new Menu("Search");
		searchStudentItem = new MenuItem("Student");
		searchFacultyItem = new MenuItem("Faculty");
		searchCourseItem = new MenuItem("Course");
		searchTextBookItem = new MenuItem("Text Book");

		removeMenu = new Menu("Remove");
		removeStudentItem = new MenuItem("Student");
		removeFacultyItem = new MenuItem("Faculty");
		removeCourseItem = new MenuItem("Course");
		removeTextBookItem = new MenuItem("Text Book");

		insertMenu = new Menu("Insert");
		insertStudentItem = new MenuItem("Student");
		insertFacultyItem = new MenuItem("Faculty");
		insertCourseItem = new MenuItem("Course");
		insertTextBookItem = new MenuItem("Text Book");

		updateMenu = new Menu("Update");
		updateStudentItem = new MenuItem("Student");
		updateFacultyItem = new MenuItem("Faculty");
		updateCourseItem = new MenuItem("Course");
		updateTextBookItem = new MenuItem("Text Book");
		root.getMiddleStudentPane().getCreditsTakingField().setEditable(false);

		displayMenu = new Menu("Display");
		displayStudentItem = new MenuItem("Student");
		displayFacultyItem = new MenuItem("Faculty");
		displayCourseItem = new MenuItem("Course");
		displayTextBookItem = new MenuItem("Text Book");

		fileMenu.getItems().addAll(importItem, exportItem, saveItem, loadItem, exitItem);
		insertMenu.getItems().addAll(insertStudentItem, insertFacultyItem, insertCourseItem, insertTextBookItem);
		searchMenu.getItems().addAll(searchStudentItem, searchFacultyItem, searchCourseItem, searchTextBookItem);
		removeMenu.getItems().addAll(removeStudentItem, removeFacultyItem, removeCourseItem, removeTextBookItem);
		updateMenu.getItems().addAll(updateStudentItem, updateFacultyItem, updateCourseItem, updateTextBookItem);
		displayMenu.getItems().addAll(displayStudentItem, displayFacultyItem, displayCourseItem, displayTextBookItem);
		menuBar.getMenus().addAll(fileMenu, insertMenu, searchMenu, removeMenu, updateMenu, displayMenu);

		final FileChooser fileChooser = new FileChooser();
		FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("TEXT files (*.txt)", "*.txt");
		fileChooser.getExtensionFilters().add(extFilter);
		File defaultDirectory = new File("Data");
		fileChooser.setInitialDirectory(defaultDirectory);

		importStudentItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(final ActionEvent e) {
				// load file
				studentFile ="";
				File file = fileChooser.showOpenDialog(primaryStage);
				studentFile =file.toString();
				studentBag.importStudentFile(file);
				
			}
		});

		importFacultyItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(final ActionEvent e) {
				// load file
				facultyFile = "";
				File file = fileChooser.showOpenDialog(primaryStage);				
				facultyFile =file.toString();
				facultyBag.importFacultyFile(file);

			}
		});

		importCourseItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(final ActionEvent e) {
				// load file
				courseFile = "";
				File file = fileChooser.showOpenDialog(primaryStage);
				courseFile = file.toString();
				courseBag.importCourse(file);

			}
		});

		importTextBookItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(final ActionEvent e) {
				// load file
				textBookFile = "";
				File file = fileChooser.showOpenDialog(primaryStage);
				textBookBag.importTextBook(file);
				
			}
		});

		exportStudentItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(final ActionEvent e) {
				Stage exportStudentDisplayStage = new Stage();
				exportStudentDisplayStage.setTitle("Remove");
				VBox exportSPane = new VBox(10);

				exportSPane.setPadding(new Insets(20));
				Label exportStudentLbl = new Label("Export To Data Folder");
				TextField exportStudentField = new TextField();
				if(studentFile!=null) {
					exportStudentField.setText(studentFile);
				}
				Button exportSBtn = new Button("Export");
				exportSBtn.setAlignment(Pos.CENTER);
				exportSPane.getChildren().add(exportStudentLbl);
				exportSPane.getChildren().add(exportStudentField);
				exportSPane.getChildren().add(exportSBtn);

				exportSBtn.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent e) {
						String fileName = exportStudentField.getText();
						if (fileName.contains(".txt")) {
							File file = new File(fileName);
							studentBag.saveStudent(file);
						} else {
							File file = new File("Data/" + fileName + ".txt");
							studentBag.saveStudent(file);
						}
						exportStudentDisplayStage.close();
					}
				});

				exportSPane.autosize();
				Scene studentExportScene = new Scene(exportSPane);
				exportStudentDisplayStage.setScene(studentExportScene);
				exportStudentDisplayStage.show();

			}
		});

		exportFacultyItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(final ActionEvent e) {
				Stage exportFacultyDisplayStage = new Stage();
				exportFacultyDisplayStage.setTitle("Export");
				VBox exportFPane = new VBox(10);
				exportFPane.setPadding(new Insets(20));
				Label exportFacultyLbl = new Label("Export To Data Folder");
				TextField exportFacultyField = new TextField();
				if(facultyFile!=null)
				{
					exportFacultyField.setText(facultyFile);
				}
				

				Button exportFBtn = new Button("Export");
				exportFBtn.setAlignment(Pos.CENTER);
				exportFPane.getChildren().add(exportFacultyLbl);
				exportFPane.getChildren().add(exportFacultyField);
				exportFPane.getChildren().add(exportFBtn);

				exportFBtn.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent e) {
						String fileName = exportFacultyField.getText();
						if (fileName.contains(".txt")) {
							File file = new File(fileName);
							facultyBag.saveFaculty(file);
						} else {
							File file = new File("Data/" + fileName + ".txt");
							facultyBag.saveFaculty(file);
						}

						exportFacultyDisplayStage.close();
					}
				});

				exportFPane.autosize();
				Scene studentExportScene = new Scene(exportFPane);
				exportFacultyDisplayStage.setScene(studentExportScene);
				exportFacultyDisplayStage.show();

			}
		});

		exportCourseItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(final ActionEvent e) {
				Stage exportCourseDisplayStage = new Stage();
				exportCourseDisplayStage.setTitle("Export");
				VBox exportCPane = new VBox(10);

				exportCPane.setPadding(new Insets(20));
				Label exportCourseLbl = new Label("Export To Data Folder");
				TextField exportCourseField = new TextField();
				Button exportCBtn = new Button("Export");
				exportCBtn.setAlignment(Pos.CENTER);
				if(courseFile!=null)
				{
					exportCourseField.setText(courseFile);
				}
				exportCPane.getChildren().add(exportCourseLbl);
				exportCPane.getChildren().add(exportCourseField);
				exportCPane.getChildren().add(exportCBtn);

				exportCBtn.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent e) {
						String fileName = exportCourseField.getText();
						if (fileName.contains(".txt")) {
							File file = new File(fileName);
							courseBag.exportCourse(file);
						} else {
							File file = new File("Data/" + fileName + ".txt");
							courseBag.exportCourse(file);
						}

						exportCourseDisplayStage.close();
					}
				});

				exportCPane.autosize();
				Scene studentExportScene = new Scene(exportCPane);
				exportCourseDisplayStage.setScene(studentExportScene);
				exportCourseDisplayStage.show();

			}
		});

		exportTextBookItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(final ActionEvent e) {
				Stage exportTextBookDisplayStage = new Stage();
				exportTextBookDisplayStage.setTitle("Export");
				VBox exportTBPane = new VBox(10);

				exportTBPane.setPadding(new Insets(20));
				Label exportTextBookLbl = new Label("Export To Data Folder");
				TextField exportTextBookField = new TextField();
				Button exportTBBtn = new Button("Export");
				exportTBBtn.setAlignment(Pos.CENTER);
				if(textBookFile!=null)
				{
					exportTextBookField.setText(textBookFile);
				}
				exportTBPane.getChildren().add(exportTextBookLbl);
				exportTBPane.getChildren().add(exportTextBookField);
				exportTBPane.getChildren().add(exportTBBtn);

				exportTBBtn.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent e) {
						String fileName = exportTextBookField.getText();
						if (fileName.contains(".txt")) {
							File file = new File(fileName);
							textBookBag.exportTextBook(file);
						} else {
							File file = new File("Data/" + fileName + ".txt");
							textBookBag.exportTextBook(file);
						}

						exportTextBookDisplayStage.close();
					}
				});

				exportTBPane.autosize();
				Scene studentExportScene = new Scene(exportTBPane);
				exportTextBookDisplayStage.setScene(studentExportScene);
				exportTextBookDisplayStage.show();

			}
		});

		/**
		 * Student View
		 */
		insertStudentItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				contentsBox.getChildren().clear();
				buttonsBox.getChildren().clear();
				clearAreas();
				root.getMiddleStudentPane().loadArray();
				contentsBox.setStyle("-fx-background-color:#ffffff");
				contentsBox.getChildren().add(root.getTopPersonPane().getTopPersonPane());
				contentsBox.getChildren().add(root.getMiddleStudentPane().getMiddleStudentPane());
				buttonsBox.getChildren().add(root.getBottomButtonPane().getInsertStudentBtn());
				buttonsBox.getChildren().add(root.getBottomButtonPane().getDisplayStudentBtn());
				contentsBox.setAlignment(Pos.CENTER);
				buttonsBox.setAlignment(Pos.CENTER);
			}
		});

		root.getTopPersonPane().getAddressPane().getStateView().getSelectionModel().selectedItemProperty()
				.addListener(new ChangeListener<String>() {
					@Override
					public void changed(ObservableValue<? extends String> observable, String oldValue,
							String newValue) {

						if (newValue != "") {
							stateString = newValue;
							root.getTopPersonPane().getAddressPane().setStateField(newValue);
						} else if (newValue == "") {
							stateString = oldValue;
							root.getTopPersonPane().getAddressPane().setStateField(newValue);
						}
					}
				});

		root.getMiddleStudentPane().getCoursesTakingLV().getSelectionModel().selectedItemProperty()
				.addListener(new ChangeListener<String>() {
					@Override
					public void changed(ObservableValue<? extends String> observable, String oldValue,
							String newValue) {

						if (newValue != "") {
							nv = newValue;
							coursesTakingArrayString.add((nv));
							if (nv != null) {
								testCourse = courseBag.search(nv);
								if (testCourse != null) {
									creditsTakingInt = creditsTakingInt + testCourse.getCourseCredits();

								}

							}

						} else if (newValue == "") {
							ov = newValue;

							coursesTakingArrayString.add((ov));
							if (ov != null) {
								testCourse = courseBag.search(nv);
								if (testCourse != null) {

									creditsTakingInt = creditsTakingInt + testCourse.getCourseCredits();

								}

							}
						}

						root.getMiddleStudentPane().getCreditsTakingField().setText(String.valueOf(creditsTakingInt));

					}
				});

		root.getMiddleStudentPane().getCoursesTookLV().getSelectionModel().selectedItemProperty()
				.addListener(new ChangeListener<String>() {
					@Override
					public void changed(ObservableValue<? extends String> observable, String oldValue,
							String newValue) {

						if (newValue != "") {
							nv = newValue;
							coursesTookArrayString.add((nv));
						} else if (newValue == "") {
							ov = newValue;
							coursesTookArrayString.add((ov));
						}
					}
				});

		root.getMiddleStudentPane().getMajorLV().getSelectionModel().selectedItemProperty()
				.addListener(new ChangeListener<String>() {
					@Override
					public void changed(ObservableValue<? extends String> observable, String oldValue,
							String newValue) {

						if (newValue != "") {
							major = newValue;

						} else if (newValue == "") {
							major = newValue;

						}
					}
				});

		root.getBottomButtonPane().getInsertStudentBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				String firstName = root.getTopPersonPane().getPersonFirstNameField().getText();
				String lastName = root.getTopPersonPane().getPersonLastNameField().getText();
				String phoneNumber = root.getTopPersonPane().getPhoneNumberField().getText();
				if (validatePhoneNumber(phoneNumber) != true) {
					VBox phoneNumBox = new VBox(10);
					Stage phoneInput = new Stage();
					phoneInput.setTitle("Phone Number isn't inputted correctly");
					Label infoPhone = new Label("Please Enter Phone Number again\n###-###-####");

					phoneNumBox.getChildren().addAll(infoPhone);
					phoneNumBox.autosize();
					Scene scene4 = new Scene(phoneNumBox);
					phoneInput.setScene(scene4);
					phoneInput.showAndWait();
				}
				if (validateZipCode(root.getTopPersonPane().getAddressPane().getZipCodeField().getText()) != true) {
					VBox phoneNumBox = new VBox(10);
					Stage phoneInput = new Stage();
					phoneInput.setTitle("Zipcode isn't inputted correctly");
					Label infoPhone = new Label("Please Enter Zipcode again\n#####");

					phoneNumBox.getChildren().addAll(infoPhone);
					phoneNumBox.autosize();
					Scene scene4 = new Scene(phoneNumBox);
					phoneInput.setScene(scene4);
					phoneInput.showAndWait();
				} else {
					Address address = new Address(
							root.getTopPersonPane().getAddressPane().getStreetNumberField().getText(),
							root.getTopPersonPane().getAddressPane().getStreetNameField().getText(),
							root.getTopPersonPane().getAddressPane().getCityField().getText(), stateString,
							root.getTopPersonPane().getAddressPane().getZipCodeField().getText());

					String coursesNeededString = root.getMiddleStudentPane().getCoursesNeededArea().getText();
					ArrayList<String> coursesNeededStringArray = new ArrayList<String>(
							Arrays.asList(coursesNeededString.split(",")));
					for (int i = 0; i < coursesNeededStringArray.size(); i++) {
						coursesNeededArray.add(courseBag.search(coursesNeededStringArray.get(i)));
					}

					String gpaS = root.getMiddleStudentPane().getGpaField().getText();
					String creditsS = root.getMiddleStudentPane().getCreditsTakingField().getText();
					double gpa = Double.parseDouble(gpaS);
					// double creditsTaking = Double.parseDouble(creditsS);

					for (int i = 0; i < coursesTakingArrayString.size(); i++) {
						coursesTakingArray.add(courseBag.search(coursesTakingArrayString.get(i)));

					}
					for (int i = 0; i < coursesTookArrayString.size(); i++) {
						coursesTookArray.add(courseBag.search(coursesTookArrayString.get(i)));
					}
					// for (int i = 0; i < coursesTakingArray.size(); i++) {
					// creditsTakingInt +=
					// coursesTakingArray.get(i).getCourseCredits();
					// }
					// root.getMiddleStudentPane().getCreditsTakingField().setText(String.valueOf(creditsTakingInt));

					coursesTakingArray.removeAll(Collections.singleton(null));
					coursesTookArray.removeAll(Collections.singleton(null));
					coursesNeededArray.removeAll(Collections.singleton(null));
					root.getMiddleStudentPane().getCreditsTakingField().setText(String.valueOf(creditsTakingInt));
					Student s1 = new Student(firstName, lastName, phoneNumber, address, coursesTookArray,
							coursesTakingArray, coursesNeededArray, gpa, creditsTakingInt, major);

					studentBag.add(s1);

					clearAreas();
					coursesTakingArray = new ArrayList<Course>();
					coursesTookArray = new ArrayList<Course>();
					coursesTookArrayString.clear();
					coursesTakingArrayString.clear();
					creditsTakingInt = 0;
				}

			}
		});

		root.getBottomButtonPane().getDisplayStudentBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Stage displayStudentStage = new Stage();
				displayStudentStage.setTitle("Student Display");
				TextArea studentDisplayArea = new TextArea();
				studentDisplayArea.setText(studentBag.displayStudent());
				studentDisplayArea.autosize();
				Scene courseScene = new Scene(studentDisplayArea);
				displayStudentStage.setScene(courseScene);
				displayStudentStage.show();
			}
		});

		removeStudentItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Stage removeStudentDisplayStage = new Stage();
				removeStudentDisplayStage.setTitle("Remove");
				VBox removeSPane = new VBox(10);

				removeSPane.setPadding(new Insets(20));
				Label removeStudentLbl = new Label("Enter Student ID to remove");
				TextField removeStudentField = new TextField();
				Button removeSBtn = new Button("Remove");
				removeSBtn.setAlignment(Pos.CENTER);
				removeSPane.getChildren().add(removeStudentLbl);
				removeSPane.getChildren().add(removeStudentField);
				removeSPane.getChildren().add(removeSBtn);

				removeSBtn.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent e) {
						if (studentBag.isStudent(removeStudentField.getText())) {
							studentBag.removeByID(removeStudentField.getText());
							removeStudentDisplayStage.close();
						} else {
							removeStudentLbl.setText("Invalid Student ID, Try Again");
						}
					}
				});

				removeSPane.autosize();
				Scene studentRemoveScene = new Scene(removeSPane);
				removeStudentDisplayStage.setScene(studentRemoveScene);
				removeStudentDisplayStage.show();
			}
		});

		searchStudentItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Stage searchStudentDisplayStage = new Stage();
				searchStudentDisplayStage.setTitle("Search Student");
				VBox searchSPane = new VBox(10);

				searchSPane.setPadding(new Insets(20));
				Label SearchStudentLbl = new Label("Enter Student ID to search");
				TextField searchStudentField = new TextField();
				Button searchSBtn = new Button("Search");
				searchSBtn.setAlignment(Pos.CENTER);
				searchSPane.getChildren().add(SearchStudentLbl);
				searchSPane.getChildren().add(searchStudentField);
				searchSPane.getChildren().add(searchSBtn);

				searchSBtn.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent e) {
						if (studentBag.isStudent(searchStudentField.getText())) {
							Student defaultStudent = (Student) studentBag.contains(searchStudentField.getText());
							searchStudentDisplayStage.close();
							insertStudentItem.fire();
							buttonsBox.getChildren().clear();
							root.getTopPersonPane().setPersonFirstNameField(defaultStudent.getFirstName());
							root.getTopPersonPane().setPersonLastNameField(defaultStudent.getLastName());
							root.getTopPersonPane().setPersonIDField(defaultStudent.getId());
							root.getTopPersonPane().setPhoneNumberField(defaultStudent.getPhoneNumber());
							root.getTopPersonPane().getAddressPane()
									.setStreetNumberField(defaultStudent.getAddress().getStreetNum());
							root.getTopPersonPane().getAddressPane()
									.setStreetNameField(defaultStudent.getAddress().getStreetName());
							root.getTopPersonPane().getAddressPane()
									.setCityField(defaultStudent.getAddress().getCity());
							root.getTopPersonPane().getAddressPane().getStateView().getSelectionModel()
									.select(defaultStudent.getAddress().getState());
							root.getTopPersonPane().getAddressPane()
									.setStateField(defaultStudent.getAddress().getState());
							root.getTopPersonPane().getAddressPane()
									.setZipCodeField(defaultStudent.getAddress().getZipCode());
							//
							root.getMiddleStudentPane().getCoursesTakingLV().getSelectionModel()
									.select(defaultStudent.getCoursesTaking().toString());
							root.getMiddleStudentPane().getCoursesTookLV().getSelectionModel()
									.select(defaultStudent.getCoursesTook().toString());
							root.getMiddleStudentPane().getMajorLV().getSelectionModel()
									.select(defaultStudent.getMajor());
							root.getMiddleStudentPane().setGpaField(String.valueOf(defaultStudent.getGpa()));
							root.getMiddleStudentPane()
									.setCreditsTakingField(String.valueOf(defaultStudent.getCreditsTaking()));

						} else {
							SearchStudentLbl.setText("Invalid Student ID, Try Again");
						}
					}
				});

				searchSPane.autosize();
				Scene studentRemoveScene = new Scene(searchSPane);
				searchStudentDisplayStage.setScene(studentRemoveScene);
				searchStudentDisplayStage.show();
			}
		});

		updateStudentItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Stage updateStudentDisplayStage = new Stage();
				updateStudentDisplayStage.setTitle("Search Student");
				VBox updateSPane = new VBox(10);

				updateSPane.setPadding(new Insets(20));
				Label updateStudentLbl = new Label("Enter Student ID to search Then update");
				TextField updateStudentField = new TextField();
				Button updateSBtn = new Button("Search");
				updateSBtn.setAlignment(Pos.CENTER);
				updateSPane.getChildren().add(updateStudentLbl);
				updateSPane.getChildren().add(updateStudentField);
				updateSPane.getChildren().add(updateSBtn);

				updateSBtn.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent e) {
						if (studentBag.isStudent(updateStudentField.getText())) {
							Student defaultStudent = (Student) studentBag.contains(updateStudentField.getText());
							updateStudentDisplayStage.close();
							insertStudentItem.fire();
							buttonsBox.getChildren().clear();
							buttonsBox.getChildren().add(root.getBottomButtonPane().getReInsertCoursesTakingBtn());
							buttonsBox.getChildren().add(root.getBottomButtonPane().getUpdateBtn());
							creditsTakingInt = defaultStudent.getCreditsTaking();
							buttonsBox.getChildren().add(root.getBottomButtonPane().getReInsertCoursesTookBtn());

							root.getTopPersonPane().setPersonFirstNameField(defaultStudent.getFirstName());
							root.getTopPersonPane().setPersonLastNameField(defaultStudent.getLastName());
							root.getTopPersonPane().setPersonIDField(defaultStudent.getId());
							root.getTopPersonPane().setPhoneNumberField(defaultStudent.getPhoneNumber());
							root.getTopPersonPane().getAddressPane()
									.setStreetNumberField(defaultStudent.getAddress().getStreetNum());
							root.getTopPersonPane().getAddressPane()
									.setStreetNameField(defaultStudent.getAddress().getStreetName());
							root.getTopPersonPane().getAddressPane()
									.setCityField(defaultStudent.getAddress().getCity());
							root.getTopPersonPane().getAddressPane().getStateView().getSelectionModel()
									.select(defaultStudent.getAddress().getState());
							root.getTopPersonPane().getAddressPane()
									.setStateField(defaultStudent.getAddress().getState());
							root.getTopPersonPane().getAddressPane()
									.setZipCodeField(defaultStudent.getAddress().getZipCode());
							//
							root.getMiddleStudentPane().getCoursesTakingLV().getSelectionModel()
									.select(defaultStudent.getCoursesTaking().toString());
							root.getMiddleStudentPane().getCoursesTookLV().getSelectionModel()
									.select(defaultStudent.getCoursesTook().toString());
							root.getMiddleStudentPane().getMajorLV().getSelectionModel()
									.select(defaultStudent.getMajor());
							root.getMiddleStudentPane().setGpaField(String.valueOf(defaultStudent.getGpa()));
							root.getMiddleStudentPane()
									.setCreditsTakingField(String.valueOf(defaultStudent.getCreditsTaking()));

							root.getBottomButtonPane().getReInsertCoursesTakingBtn()
									.setOnAction(new EventHandler<ActionEvent>() {
								@Override
								public void handle(ActionEvent e) {
									defaultStudent.getCoursesTaking().clear();
								}
							});
							root.getBottomButtonPane().getReInsertCoursesTookBtn()
									.setOnAction(new EventHandler<ActionEvent>() {
								@Override
								public void handle(ActionEvent e) {
									defaultStudent.getCoursesTaking().clear();
									creditsTakingInt = 0;
								}
							});

							root.getBottomButtonPane().getUpdateBtn().setOnAction(new EventHandler<ActionEvent>() {
								@Override
								public void handle(ActionEvent e) {
									coursesTakingArray = (defaultStudent.getCoursesTaking());
									coursesTookArray = (defaultStudent.getCoursesTook());
									String firstName = root.getTopPersonPane().getPersonFirstNameField().getText();
									String lastName = root.getTopPersonPane().getPersonLastNameField().getText();
									String phoneNumber = root.getTopPersonPane().getPhoneNumberField().getText();
									if (validatePhoneNumber(phoneNumber) != true) {
										VBox phoneNumBox = new VBox(10);
										Stage phoneInput = new Stage();
										phoneInput.setTitle("Phone Number isn't inputted correctly");
										Label infoPhone = new Label("Please Enter Phone Number again\n###-###-####");

										phoneNumBox.getChildren().addAll(infoPhone);
										phoneNumBox.autosize();
										Scene scene4 = new Scene(phoneNumBox);
										phoneInput.setScene(scene4);
										phoneInput.showAndWait();
									}
									if (validateZipCode(root.getTopPersonPane().getAddressPane().getZipCodeField()
											.getText()) != true) {
										VBox phoneNumBox = new VBox(10);
										Stage phoneInput = new Stage();
										phoneInput.setTitle("Zipcode isn't inputted correctly");
										Label infoPhone = new Label("Please Enter Zipcode again\n#####");

										phoneNumBox.getChildren().addAll(infoPhone);
										phoneNumBox.autosize();
										Scene scene4 = new Scene(phoneNumBox);
										phoneInput.setScene(scene4);
										phoneInput.showAndWait();
									} else {
										Address address = new Address(
												root.getTopPersonPane().getAddressPane().getStreetNumberField()
														.getText(),
												root.getTopPersonPane().getAddressPane().getStreetNameField().getText(),
												root.getTopPersonPane().getAddressPane().getCityField().getText(),
												stateString,
												root.getTopPersonPane().getAddressPane().getZipCodeField().getText());
										defaultStudent.setAddress(address);
										String coursesNeededString = root.getMiddleStudentPane().getCoursesNeededArea()
												.getText();
										ArrayList<String> coursesNeededStringArray = new ArrayList<String>(
												Arrays.asList(coursesNeededString.split(",")));
										for (int i = 0; i < coursesNeededStringArray.size(); i++) {
											coursesNeededArray.add(courseBag.search(coursesNeededStringArray.get(i)));
										}

										String gpaS = root.getMiddleStudentPane().getGpaField().getText();
										String creditsS = root.getMiddleStudentPane().getCreditsTakingField().getText();
										double gpa = Double.parseDouble(gpaS);

										for (int i = 0; i < coursesTakingArrayString.size(); i++) {
											if (!coursesTakingArray
													.contains(courseBag.search(coursesTakingArrayString.get(i)))) {
												coursesTakingArray
														.add(courseBag.search(coursesTakingArrayString.get(i)));
											}

										}
										for (int i = 0; i < coursesTookArrayString.size(); i++) {

											if (!coursesTookArray
													.contains(courseBag.search(coursesTookArrayString.get(i)))) {
												coursesTookArray.add(courseBag.search(coursesTookArrayString.get(i)));
											}

										}

										coursesTakingArray.removeAll(Collections.singleton(null));
										coursesTookArray.removeAll(Collections.singleton(null));
										coursesNeededArray.removeAll(Collections.singleton(null));
										defaultStudent.setFirstName(firstName);
										defaultStudent.setLastName(lastName);
										defaultStudent.setAddress(address);
										defaultStudent.setPhoneNumber(phoneNumber);
										defaultStudent.setCoursesNeeded(coursesNeededArray);
										defaultStudent.setCoursesTaking(coursesTakingArray);
										defaultStudent.setCoursesTook(coursesTookArray);
										defaultStudent.setGpa(gpa);
										int creditTest = 0;
										for (int i = 0; i < coursesTakingArray.size(); i++) {
											creditTest += coursesTakingArray.get(i).getCourseCredits();
										}
										defaultStudent.setCreditsTaking(creditTest);
										defaultStudent.setMajor(major);
										studentBag.update(defaultStudent);
										creditsTakingInt = 0;
										clearAreas();

									}

								}
							});

						} else {
							updateStudentLbl.setText("Invalid Student ID, Try Again");
						}
						coursesTakingArray = new ArrayList<Course>();
						coursesTookArray = new ArrayList<Course>();
						coursesTookArrayString.clear();
						coursesTakingArrayString.clear();

					}

				});

				updateSPane.autosize();
				Scene studentUpdateScene = new Scene(updateSPane);
				updateStudentDisplayStage.setScene(studentUpdateScene);
				updateStudentDisplayStage.show();
			}
		});

		displayStudentItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				root.getBottomButtonPane().getDisplayStudentBtn().fire();
			}
		});

		/**
		 * Faculty View
		 */

		insertFacultyItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				contentsBox.getChildren().clear();
				buttonsBox.getChildren().clear();
				clearAreas();
				contentsBox.setStyle("-fx-background-color:#ffffff");
				contentsBox.getChildren().add(root.getTopPersonPane().getTopPersonPane());
				contentsBox.getChildren().add(root.getMiddleFacultyPane().getMiddleFacultyPane());
				buttonsBox.getChildren().add(root.getBottomButtonPane().getInsertFacultyBtn());
				buttonsBox.getChildren().add(root.getBottomButtonPane().getDisplayFacultyBtn());

				contentsBox.setAlignment(Pos.CENTER);
				buttonsBox.setAlignment(Pos.CENTER);
			}
		});

		root.getBottomButtonPane().getInsertFacultyBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				String firstName = root.getTopPersonPane().getPersonFirstNameField().getText();
				String lastName = root.getTopPersonPane().getPersonLastNameField().getText();
				String phoneNumber = root.getTopPersonPane().getPhoneNumberField().getText();
				if (validatePhoneNumber(phoneNumber) != true) {
					VBox phoneNumBox = new VBox(10);
					Stage phoneInput = new Stage();
					phoneInput.setTitle("Phone Number isn't inputted correctly");
					Label infoPhone = new Label("Please Enter Phone Number again\n###-###-####");

					phoneNumBox.getChildren().addAll(infoPhone);
					phoneNumBox.autosize();
					Scene scene4 = new Scene(phoneNumBox);
					phoneInput.setScene(scene4);
					phoneInput.showAndWait();
				}
				if (validateZipCode(root.getTopPersonPane().getAddressPane().getZipCodeField().getText()) != true) {
					VBox phoneNumBox = new VBox(10);
					Stage phoneInput = new Stage();
					phoneInput.setTitle("Zipcode isn't inputted correctly");
					Label infoPhone = new Label("Please Enter Zipcode again\n#####");

					phoneNumBox.getChildren().addAll(infoPhone);
					phoneNumBox.autosize();
					Scene scene4 = new Scene(phoneNumBox);
					phoneInput.setScene(scene4);
					phoneInput.showAndWait();
				} else {
					Address address = new Address(
							root.getTopPersonPane().getAddressPane().getStreetNumberField().getText(),
							root.getTopPersonPane().getAddressPane().getStreetNameField().getText(),
							root.getTopPersonPane().getAddressPane().getCityField().getText(), stateString,
							root.getTopPersonPane().getAddressPane().getZipCodeField().getText());
					String rank = root.getMiddleFacultyPane().getRankField().getText();
					String salaryString = root.getMiddleFacultyPane().getSalaryField().getText();
					double salary = Double.parseDouble(salaryString);

					String str = root.getMiddleFacultyPane().getCoursesTeachingField().getText();
					ArrayList<String> course = new ArrayList<String>(Arrays.asList(str.split(",")));

					courseArray = new ArrayList<Course>();
					for (int i = 0; i < course.size(); i++) {
						courseArray.add(courseBag.search(course.get(i)));
					}

					Faculty f1 = new Faculty(firstName, lastName, phoneNumber, address, rank, salary, courseArray);

					facultyBag.add(f1);

					clearAreas();

				}
			}
		});

		root.getBottomButtonPane().getDisplayFacultyBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Stage stageDisplay = new Stage();
				stageDisplay.setTitle("Faculty Display");
				TextArea facultyDisplayArea = new TextArea();
				facultyDisplayArea.setText(facultyBag.displayFaculty());
				facultyDisplayArea.autosize();
				Scene facultyScene = new Scene(facultyDisplayArea);
				stageDisplay.setScene(facultyScene);
				stageDisplay.show();
			}
		});

		removeFacultyItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Stage removeFacultyDisplayStage = new Stage();
				removeFacultyDisplayStage.setTitle("Remove");
				VBox removeFPane = new VBox(10);

				removeFPane.setPadding(new Insets(20));
				Label removeFacultyLbl = new Label("Enter Faculty ID to remove");
				TextField removeFacultyField = new TextField();
				Button removeFBtn = new Button("Remove");
				removeFBtn.setAlignment(Pos.CENTER);
				removeFPane.getChildren().add(removeFacultyLbl);
				removeFPane.getChildren().add(removeFacultyField);
				removeFPane.getChildren().add(removeFBtn);

				removeFBtn.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent e) {
						if (facultyBag.isFaculty(removeFacultyField.getText())) {

							facultyBag.removeByID(removeFacultyField.getText());
							removeFacultyDisplayStage.close();

						} else {
							removeFacultyLbl.setText("Invalid ID,Try again");
						}
					}
				});

				removeFPane.autosize();
				Scene studentRemoveScene = new Scene(removeFPane);
				removeFacultyDisplayStage.setScene(studentRemoveScene);
				removeFacultyDisplayStage.show();
			}
		});

		searchFacultyItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Stage searchFacultyDisplayStage = new Stage();
				searchFacultyDisplayStage.setTitle("Search Faculty");
				VBox searchFPane = new VBox(10);

				searchFPane.setPadding(new Insets(20));
				Label SearchFacultyLbl = new Label("Enter Faculty ID to search");
				TextField searchFacultyField = new TextField();
				Button searchFBtn = new Button("Search");
				searchFBtn.setAlignment(Pos.CENTER);
				searchFPane.getChildren().add(SearchFacultyLbl);
				searchFPane.getChildren().add(searchFacultyField);
				searchFPane.getChildren().add(searchFBtn);

				searchFBtn.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent e) {
						if (facultyBag.isFaculty(searchFacultyField.getText())) {
							Faculty defaultFaculty = (Faculty) facultyBag.contains(searchFacultyField.getText());
							searchFacultyDisplayStage.close();
							insertFacultyItem.fire();
							buttonsBox.getChildren().clear();
							root.getTopPersonPane().setPersonFirstNameField(defaultFaculty.getFirstName());
							root.getTopPersonPane().setPersonLastNameField(defaultFaculty.getLastName());
							root.getTopPersonPane().setPersonIDField(defaultFaculty.getId());
							root.getTopPersonPane().setPhoneNumberField(defaultFaculty.getPhoneNumber());
							root.getTopPersonPane().getAddressPane()
									.setStreetNumberField(defaultFaculty.getAddress().getStreetNum());
							root.getTopPersonPane().getAddressPane()
									.setStreetNameField(defaultFaculty.getAddress().getStreetName());
							root.getTopPersonPane().getAddressPane()
									.setCityField(defaultFaculty.getAddress().getCity());
							root.getTopPersonPane().getAddressPane().getStateView().getSelectionModel()
									.select(defaultFaculty.getAddress().getState());
							root.getTopPersonPane().getAddressPane()
									.setStateField(defaultFaculty.getAddress().getState());
							root.getTopPersonPane().getAddressPane()
									.setZipCodeField(defaultFaculty.getAddress().getZipCode());
							//
							root.getMiddleFacultyPane().setRankField(defaultFaculty.getRank());
							root.getMiddleFacultyPane().setSalaryField(String.valueOf(defaultFaculty.getSalary()));

							String test = "";

							for (int i = 0; i < defaultFaculty.getCoursesTeaching().size(); i++) {
								if (!defaultFaculty.getCoursesTeaching().isEmpty() == false) {
									test += defaultFaculty.getCoursesTeaching().get(i).getCourseNumber() + ",";
								}
							}
							root.getMiddleFacultyPane().setCoursesTeachingField(test);
						} else {
							SearchFacultyLbl.setText("Invalid Faculty ID, Try Again");
						}
					}
				});

				searchFPane.autosize();
				Scene searchFacultyScene = new Scene(searchFPane);
				searchFacultyDisplayStage.setScene(searchFacultyScene);
				searchFacultyDisplayStage.show();
			}
		});

		updateFacultyItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Stage updateFacultyDisplayStage = new Stage();
				updateFacultyDisplayStage.setTitle("Update Faculty");
				VBox updateFPane = new VBox(10);

				updateFPane.setPadding(new Insets(20));
				Label updateFacultyLbl = new Label("Enter Faculty ID to search then update");
				TextField updateFacultyField = new TextField();
				Button updateFBtn = new Button("Search");
				updateFBtn.setAlignment(Pos.CENTER);
				updateFPane.getChildren().add(updateFacultyLbl);
				updateFPane.getChildren().add(updateFacultyField);
				updateFPane.getChildren().add(updateFBtn);

				updateFBtn.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent e) {
						if (facultyBag.isFaculty(updateFacultyField.getText())) {
							Faculty defaultFaculty = (Faculty) facultyBag.contains(updateFacultyField.getText());
							updateFacultyDisplayStage.close();
							insertFacultyItem.fire();
							buttonsBox.getChildren().clear();
							buttonsBox.getChildren().add(root.getBottomButtonPane().getUpdateBtn());
							root.getTopPersonPane().setPersonFirstNameField(defaultFaculty.getFirstName());
							root.getTopPersonPane().setPersonLastNameField(defaultFaculty.getLastName());
							root.getTopPersonPane().setPersonIDField(defaultFaculty.getId());
							root.getTopPersonPane().setPhoneNumberField(defaultFaculty.getPhoneNumber());
							root.getTopPersonPane().getAddressPane()
									.setStreetNumberField(defaultFaculty.getAddress().getStreetNum());
							root.getTopPersonPane().getAddressPane()
									.setStreetNameField(defaultFaculty.getAddress().getStreetName());
							root.getTopPersonPane().getAddressPane()
									.setCityField(defaultFaculty.getAddress().getCity());
							root.getTopPersonPane().getAddressPane().getStateView().getSelectionModel()
									.select(defaultFaculty.getAddress().getState());
							root.getTopPersonPane().getAddressPane()
									.setStateField(defaultFaculty.getAddress().getState());
							root.getTopPersonPane().getAddressPane()
									.setZipCodeField(defaultFaculty.getAddress().getZipCode());
							//
							defaultFaculty.getCoursesTeaching().removeAll(Collections.singleton(null));
							String test = "";
							if (defaultFaculty.getCoursesTeaching().isEmpty() == false) {
								for (int i = 0; i < defaultFaculty.getCoursesTeaching().size(); i++) {
									test += defaultFaculty.getCoursesTeaching().get(i).getCourseNumber() + ",";
								}
							}

							root.getMiddleFacultyPane().setRankField(defaultFaculty.getRank());
							root.getMiddleFacultyPane().setSalaryField(String.valueOf(defaultFaculty.getSalary()));
							root.getMiddleFacultyPane().setCoursesTeachingField(test);

							root.getBottomButtonPane().getUpdateBtn().setOnAction(new EventHandler<ActionEvent>() {
								@Override
								public void handle(ActionEvent e) {

									String firstName = root.getTopPersonPane().getPersonFirstNameField().getText();
									String lastName = root.getTopPersonPane().getPersonLastNameField().getText();
									String phoneNumber = root.getTopPersonPane().getPhoneNumberField().getText();
									if (validatePhoneNumber(phoneNumber) != true) {
										VBox phoneNumBox = new VBox(10);
										Stage phoneInput = new Stage();
										phoneInput.setTitle("Phone Number isn't inputted correctly");
										Label infoPhone = new Label("Please Enter Phone Number again\n###-###-####");

										phoneNumBox.getChildren().addAll(infoPhone);
										phoneNumBox.autosize();
										Scene scene4 = new Scene(phoneNumBox);
										phoneInput.setScene(scene4);
										phoneInput.showAndWait();
									}
									if (validateZipCode(root.getTopPersonPane().getAddressPane().getZipCodeField()
											.getText()) != true) {
										VBox phoneNumBox = new VBox(10);
										Stage phoneInput = new Stage();
										phoneInput.setTitle("Zipcode isn't inputted correctly");
										Label infoPhone = new Label("Please Enter Zipcode again\n#####");

										phoneNumBox.getChildren().addAll(infoPhone);
										phoneNumBox.autosize();
										Scene scene4 = new Scene(phoneNumBox);
										phoneInput.setScene(scene4);
										phoneInput.showAndWait();
									} else {
										Address address = new Address(
												root.getTopPersonPane().getAddressPane().getStreetNumberField()
														.getText(),
												root.getTopPersonPane().getAddressPane().getStreetNameField().getText(),
												root.getTopPersonPane().getAddressPane().getCityField().getText(),
												stateString,
												root.getTopPersonPane().getAddressPane().getZipCodeField().getText());
										String rank = root.getMiddleFacultyPane().getRankField().getText();
										String salaryString = root.getMiddleFacultyPane().getSalaryField().getText();
										double salary = Double.parseDouble(salaryString);

										String str = root.getMiddleFacultyPane().getCoursesTeachingField().getText();
										ArrayList<String> course = new ArrayList<String>(Arrays.asList(str.split(",")));

										courseArray = new ArrayList<Course>();
										for (int i = 0; i < course.size(); i++) {
											courseArray.add(courseBag.search(course.get(i)));
										}
										defaultFaculty.setFirstName(firstName);
										defaultFaculty.setLastName(lastName);
										defaultFaculty.setPhoneNumber(phoneNumber);
										defaultFaculty.setAddress(address);
										defaultFaculty.setRank(rank);
										defaultFaculty.setSalary(salary);
										defaultFaculty.setCoursesTeaching(courseArray);

										facultyBag.update(defaultFaculty);

										clearAreas();
									}

								}
							});

						} else {
							updateFacultyLbl.setText("Invalid Faculty ID, Try Again");
						}
					}
				});

				updateFPane.autosize();
				Scene searchFacultyScene = new Scene(updateFPane);
				updateFacultyDisplayStage.setScene(searchFacultyScene);
				updateFacultyDisplayStage.show();
			}
		});

		displayFacultyItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				root.getBottomButtonPane().getDisplayFacultyBtn().fire();
			}
		});

		/**
		 * Course View
		 */

		insertCourseItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				contentsBox.getChildren().clear();
				buttonsBox.getChildren().clear();
				contentsBox.setStyle("-fx-background-color:#abcdef");
				contentsBox.getChildren().add(courseRoot.getCoursePane());
				buttonsBox.getChildren().add(courseRoot.getInsertBtn());
				buttonsBox.getChildren().add(courseRoot.getDisplayBtn());
				contentsBox.setAlignment(Pos.CENTER);
				buttonsBox.setAlignment(Pos.CENTER);
			}
		});
		courseRoot.getInsertBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {

				String str = courseRoot.getTextBookArea().getText();
				ArrayList<String> tb = new ArrayList<String>(Arrays.asList(str.split(",")));
				textBookArray = new ArrayList<TextBook>();
				for (int i = 0; i < tb.size(); i++) {
					textBookArray.add(textBookBag.searchByBookISBN(tb.get(i)));
				}

				Course c1 = new Course(courseRoot.getCourseTitleField().getText(),
						courseRoot.getCourseDescriptionArea().getText(),
						Double.parseDouble(courseRoot.getCourseCreditField().getText()), textBookArray);
				courseBag.add(c1);
				courseRoot.getCourseTitleField().clear();
				courseRoot.getCourseDescriptionArea().clear();
				courseRoot.getCourseCreditField().clear();
				courseRoot.getTextBookArea().clear();
				root.getMiddleStudentPane().setListViews(courseBag);
			}
		});

		courseRoot.getDisplayBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Stage stageDisplay = new Stage();
				stageDisplay.setTitle("Course Display");
				TextArea courseDisplay = new TextArea();
				courseDisplay.setText(courseBag.display());
				courseDisplay.autosize();
				Scene courseScene = new Scene(courseDisplay);
				stageDisplay.setScene(courseScene);
				stageDisplay.show();
			}
		});

		removeCourseItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Stage removeCourseDisplayStage = new Stage();
				removeCourseDisplayStage.setTitle("Remove");
				VBox removeCPane = new VBox(10);

				removeCPane.setPadding(new Insets(20));
				Label removeCourseLbl = new Label("Enter CRN to remove");
				TextField removeCourseField = new TextField();
				Button removeCBtn = new Button("Remove");
				removeCBtn.setAlignment(Pos.CENTER);
				removeCPane.getChildren().add(removeCourseLbl);
				removeCPane.getChildren().add(removeCourseField);
				removeCPane.getChildren().add(removeCBtn);

				removeCBtn.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent e) {
						if (courseBag.search(removeCourseField.getText()) != null) {
							courseBag.remove(removeCourseField.getText());
							removeCourseDisplayStage.close();
						} else {
							removeCourseLbl.setText("Invalid CRN, Try Again");
						}
					}
				});

				removeCPane.autosize();
				Scene studentRemoveScene = new Scene(removeCPane);
				removeCourseDisplayStage.setScene(studentRemoveScene);
				removeCourseDisplayStage.show();
			}
		});

		searchCourseItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Stage searchCourseDisplayStage = new Stage();
				searchCourseDisplayStage.setTitle("Search Course");
				VBox searchCPane = new VBox(10);

				searchCPane.setPadding(new Insets(20));
				Label SearchCourseLbl = new Label("Enter Course CRN to search");
				TextField searchCourseField = new TextField();
				Button searchCBtn = new Button("Search");
				searchCBtn.setAlignment(Pos.CENTER);
				searchCPane.getChildren().add(SearchCourseLbl);
				searchCPane.getChildren().add(searchCourseField);
				searchCPane.getChildren().add(searchCBtn);

				searchCBtn.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent e) {
						if (courseBag.search(searchCourseField.getText()) != null) {
							Course defaultCourse = courseBag.search(searchCourseField.getText());
							searchCourseDisplayStage.close();
							insertCourseItem.fire();
							buttonsBox.getChildren().clear();
							defaultCourse.getTextBooks().removeAll(Collections.singleton(null));
							String cTBString = "";
							if (!defaultCourse.getTextBooks().equals(null)) {
								for (int i = 0; i < defaultCourse.getTextBooks().size(); i++) {
									cTBString += defaultCourse.getTextBooks().get(i).getBookISBN();
								}
							}

							courseRoot.getCourseNumberField().setText(defaultCourse.getCourseNumber());
							courseRoot.getCourseTitleField().setText(defaultCourse.getCourseTitle());
							courseRoot.getCourseDescriptionArea().setText(defaultCourse.getCourseDescription());
							courseRoot.getCourseCreditField().setText(String.valueOf(defaultCourse.getCourseCredits()));
							courseRoot.getTextBookArea().setText((String) cTBString);

						} else {
							SearchCourseLbl.setText("Invalid Course CRN, Try Again");
						}
					}
				});

				searchCPane.autosize();
				Scene searchCourseScene = new Scene(searchCPane);
				searchCourseDisplayStage.setScene(searchCourseScene);
				searchCourseDisplayStage.show();
			}
		});

		displayCourseItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				courseRoot.getDisplayBtn().fire();
			}
		});

		updateCourseItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Stage updateCourseDisplayStage = new Stage();
				updateCourseDisplayStage.setTitle("Search Course");
				VBox updateCPane = new VBox(10);

				updateCPane.setPadding(new Insets(20));
				Label updateCourseLbl = new Label("Enter Course CRN to search, then update");
				TextField updateCourseField = new TextField();
				Button updateCBtn = new Button("Search");
				updateCBtn.setAlignment(Pos.CENTER);
				updateCPane.getChildren().add(updateCourseLbl);
				updateCPane.getChildren().add(updateCourseField);
				updateCPane.getChildren().add(updateCBtn);

				updateCBtn.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent e) {
						if (courseBag.search(updateCourseField.getText()) != null) {
							Course defaultCourse = courseBag.search(updateCourseField.getText());
							updateCourseDisplayStage.close();
							insertCourseItem.fire();
							buttonsBox.getChildren().clear();
							buttonsBox.getChildren().add(courseRoot.getUpdateBtn());
							defaultCourse.getTextBooks().removeAll(Collections.singleton(null));
							String cTBString = "";
							if (!defaultCourse.getTextBooks().equals(null)) {
								for (int i = 0; i < defaultCourse.getTextBooks().size(); i++) {
									cTBString += defaultCourse.getTextBooks().get(i).getBookISBN();
								}
							}

							courseRoot.getCourseNumberField().setText(defaultCourse.getCourseNumber());
							courseRoot.getCourseTitleField().setText(defaultCourse.getCourseTitle());
							courseRoot.getCourseDescriptionArea().setText(defaultCourse.getCourseDescription());
							courseRoot.getCourseCreditField().setText(String.valueOf(defaultCourse.getCourseCredits()));

							courseRoot.getTextBookArea().setText((String) cTBString);

							courseRoot.getUpdateBtn().setOnAction(new EventHandler<ActionEvent>() {
								@Override
								public void handle(ActionEvent e) {
									String str = courseRoot.getTextBookArea().getText();
									ArrayList<String> tb = new ArrayList<String>(Arrays.asList(str.split(",")));
									textBookArray = new ArrayList<TextBook>();
									for (int i = 0; i < tb.size(); i++) {
										textBookArray.add(textBookBag.searchByBookISBN(tb.get(i)));
									}
									defaultCourse.setCourseTitle(courseRoot.getCourseTitleField().getText());
									defaultCourse.setCourseDescription(courseRoot.getCourseDescriptionArea().getText());
									defaultCourse.setCourseCredits(
											Double.parseDouble(courseRoot.getCourseCreditField().getText()));
									defaultCourse.setTextBooks(textBookArray);
									courseBag.update(defaultCourse);
									courseRoot.getCourseTitleField().clear();
									courseRoot.getCourseDescriptionArea().clear();
									courseRoot.getCourseCreditField().clear();
									courseRoot.getTextBookArea().clear();
									updateAllFaculty();
									updateAllStudent();
								}
							});

						} else {
							updateCourseLbl.setText("Invalid Course CRN, Try Again");
						}
					}
				});

				updateCPane.autosize();
				Scene updateCourseScene = new Scene(updateCPane);
				updateCourseDisplayStage.setScene(updateCourseScene);
				updateCourseDisplayStage.show();
			}
		});

		// TextBook View
		insertTextBookItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				contentsBox.getChildren().clear();
				buttonsBox.getChildren().clear();
				contentsBox.setStyle("-fx-background-color:#f4aa42");
				contentsBox.getChildren().add(textBookRoot.getTextBookPane());
				buttonsBox.getChildren().add(textBookRoot.getInsertBtn());
				buttonsBox.getChildren().add(textBookRoot.getDisplayBooksBtn());
				contentsBox.setAlignment(Pos.CENTER);
				buttonsBox.setAlignment(Pos.CENTER);
			}
		});

		textBookRoot.getInsertBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				String fn = textBookRoot.getAuthorFirstNameField().getText();
				String ln = textBookRoot.getAuthorLastNameField().getText();
				ArrayList<String> fnArray = new ArrayList<String>(Arrays.asList(fn.split(",")));
				ArrayList<String> lnArray = new ArrayList<String>(Arrays.asList(ln.split(",")));
				for (int i = 0; i < fnArray.size(); i++) {
					Author a = new Author(fnArray.get(i), lnArray.get(i));
					author.add(a);
				}

				TextBook s = new TextBook(textBookRoot.getTextBookTitleField().getText(),
						textBookRoot.getTextBookISBNField().getText(), author,
						Double.parseDouble(textBookRoot.getTextBookPriceField().getText()));
				textBookBag.add(s);
				textBookRoot.getTextBookTitleField().clear();
				textBookRoot.getTextBookISBNField().clear();
				textBookRoot.getTextBookPriceField().clear();
				textBookRoot.getAuthorFirstNameField().clear();
				textBookRoot.getAuthorLastNameField().clear();
				textBookRoot.getSearchField().clear();
				author = new ArrayList<>();
			}
		});
		textBookRoot.getDisplayBooksBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Stage stageDisplay = new Stage();
				stageDisplay.setTitle("TextBook Display");
				TextArea textBookDisplay = new TextArea();
				textBookDisplay.setText(textBookBag.display());
				textBookDisplay.autosize();
				Scene personSceneDisplay = new Scene(textBookDisplay);
				stageDisplay.setScene(personSceneDisplay);
				stageDisplay.show();

			}
		});

		removeTextBookItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Stage removeTextBookDisplayStage = new Stage();
				removeTextBookDisplayStage.setTitle("Remove");
				VBox removeTPane = new VBox(10);

				removeTPane.setPadding(new Insets(20));
				Label removeTextBookLbl = new Label("Enter ISBN to remove");
				TextField removeTextBookField = new TextField();
				Button removeTBBtn = new Button("Remove");
				removeTBBtn.setAlignment(Pos.CENTER);
				removeTPane.getChildren().add(removeTextBookLbl);
				removeTPane.getChildren().add(removeTextBookField);
				removeTPane.getChildren().add(removeTBBtn);

				removeTBBtn.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent e) {
						if (textBookBag.searchByBookISBN(removeTextBookField.getText()) != null) {
							textBookBag.removeByBookISBN(removeTextBookField.getText());
							removeTextBookDisplayStage.close();
						} else {
							removeTextBookLbl.setText("Invalid ISBN, Try Again");
						}
					}
				});

				removeTPane.autosize();
				Scene studentRemoveScene = new Scene(removeTPane);
				removeTextBookDisplayStage.setScene(studentRemoveScene);
				removeTextBookDisplayStage.show();
			}
		});

		searchTextBookItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Stage searchTextBookDisplayStage = new Stage();
				searchTextBookDisplayStage.setTitle("Search TextBook");
				VBox searchTBPane = new VBox(10);

				searchTBPane.setPadding(new Insets(20));
				Label SearchTextBookLbl = new Label("Enter Book ISBN to search");
				TextField searchTextBookField = new TextField();
				Button searchTBBtn = new Button("Search");
				searchTBBtn.setAlignment(Pos.CENTER);
				searchTBPane.getChildren().add(SearchTextBookLbl);
				searchTBPane.getChildren().add(searchTextBookField);
				searchTBPane.getChildren().add(searchTBBtn);

				searchTBBtn.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent e) {
						if (textBookBag.searchByBookISBN(searchTextBookField.getText()) != null) {
							TextBook defaultBook = textBookBag.searchByBookISBN(searchTextBookField.getText());
							searchTextBookDisplayStage.close();
							insertTextBookItem.fire();
							buttonsBox.getChildren().clear();
							String fnString = "";
							String lnString = "";

							textBookRoot.getTextBookTitleField().setText(defaultBook.getBookTitle());
							textBookRoot.getTextBookISBNField().setText(defaultBook.getBookISBN());
							textBookRoot.getTextBookPriceField().setText(String.valueOf(defaultBook.getBookPrice()));
							for (int i = 0; i < defaultBook.getBookAuthors().size(); i++) {
								fnString += defaultBook.getBookAuthors().get(i).getAuthorFirstName() + ",";
							}
							for (int j = 0; j < defaultBook.getBookAuthors().size(); j++) {
								lnString += defaultBook.getBookAuthors().get(j).getAuthorLastName() + ",";
							}
							textBookRoot.getAuthorFirstNameField().setText(fnString);
							textBookRoot.getAuthorLastNameField().setText(lnString);

						} else {
							SearchTextBookLbl.setText("Invalid ISBN, Try Again");
						}
					}
				});

				searchTBPane.autosize();
				Scene searchTextBookScene = new Scene(searchTBPane);
				searchTextBookDisplayStage.setScene(searchTextBookScene);
				searchTextBookDisplayStage.show();
			}
		});

		updateTextBookItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Stage updateTextBookDisplayStage = new Stage();
				updateTextBookDisplayStage.setTitle("Update TextBook");
				VBox updateTBPane = new VBox(10);

				updateTBPane.setPadding(new Insets(20));
				Label updateTextBookLbl = new Label("Enter Book ISBN to search, then update");
				TextField updateTextBookField = new TextField();
				Button updateTBBtn = new Button("Search");
				updateTBBtn.setAlignment(Pos.CENTER);
				updateTBPane.getChildren().add(updateTextBookLbl);
				updateTBPane.getChildren().add(updateTextBookField);
				updateTBPane.getChildren().add(updateTBBtn);

				updateTBBtn.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent e) {
						if (textBookBag.searchByBookISBN(updateTextBookField.getText()) != null) {
							TextBook defaultBook = textBookBag.searchByBookISBN(updateTextBookField.getText());
							updateTextBookDisplayStage.close();
							insertTextBookItem.fire();
							buttonsBox.getChildren().clear();
							buttonsBox.getChildren().add(textBookRoot.getUpdateBtn());
							String fnString = "";
							String lnString = "";

							textBookRoot.getTextBookTitleField().setText(defaultBook.getBookTitle());
							textBookRoot.getTextBookISBNField().setText(defaultBook.getBookISBN());
							textBookRoot.getTextBookPriceField().setText(String.valueOf(defaultBook.getBookPrice()));
							for (int i = 0; i < defaultBook.getBookAuthors().size(); i++) {
								fnString += defaultBook.getBookAuthors().get(i).getAuthorFirstName() + ",";
							}
							for (int j = 0; j < defaultBook.getBookAuthors().size(); j++) {
								lnString += defaultBook.getBookAuthors().get(j).getAuthorLastName() + ",";
							}
							textBookRoot.getAuthorFirstNameField().setText(fnString);
							textBookRoot.getAuthorLastNameField().setText(lnString);
							textBookRoot.getUpdateBtn().setOnAction(new EventHandler<ActionEvent>() {
								@Override
								public void handle(ActionEvent e) {
									String fn = textBookRoot.getAuthorFirstNameField().getText();
									String ln = textBookRoot.getAuthorLastNameField().getText();
									ArrayList<String> fnArray = new ArrayList<String>(Arrays.asList(fn.split(",")));
									ArrayList<String> lnArray = new ArrayList<String>(Arrays.asList(ln.split(",")));
									for (int i = 0; i < fnArray.size(); i++) {
										Author a = new Author(fnArray.get(i), lnArray.get(i));
										author.add(a);
									}

									defaultBook.setBookAuthors(author);
									defaultBook.setBookPrice(
											Double.parseDouble(textBookRoot.getTextBookPriceField().getText()));
									defaultBook.setBookTitle(textBookRoot.getTextBookTitleField().getText());

									textBookBag.update(defaultBook);
									textBookRoot.getTextBookTitleField().clear();
									textBookRoot.getTextBookISBNField().clear();
									textBookRoot.getTextBookPriceField().clear();
									textBookRoot.getAuthorFirstNameField().clear();
									textBookRoot.getAuthorLastNameField().clear();
									textBookRoot.getSearchField().clear();
									author = new ArrayList<>();
									updateAllCourse();
									updateAllStudent();
									updateAllFaculty();
								}
							});

						} else {
							updateTextBookLbl.setText("Invalid ISBN, Try Again");
						}
					}
				});

				updateTBPane.autosize();
				Scene updateTextBookScene = new Scene(updateTBPane);
				updateTextBookDisplayStage.setScene(updateTextBookScene);
				updateTextBookDisplayStage.show();
			}
		});

		displayTextBookItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				textBookRoot.getDisplayBooksBtn().fire();
			}
		});

		saveItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				courseBag.save();
				textBookBag.save();
				facultyBag.saveF();
				studentBag.saveS();
			}
		});
		loadItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				courseBag.load();
				textBookBag.load();
				facultyBag.loadF();
				studentBag.loadS();
			}
		});

		exitItem.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				courseBag.save();
				textBookBag.save();
				facultyBag.saveF();
				studentBag.saveS();
				Platform.exit();
			}
		});

		rootBorderPane.setTop(menuBar);
		rootBorderPane.setCenter(contentsBox);
		rootBorderPane.setBottom(buttonsBox);
		primaryStage.setMaximized(true);
		Scene scene = new Scene(rootBorderPane);
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public static void main(String[] args) {
		Application.launch(args);
	}

	public void updateAllCourse() {
		ArrayList<TextBook> tbA = new ArrayList<TextBook>();
		ArrayList<Course> courseArray = courseBag.get();
		for (int i = 0; i < courseArray.size(); i++) {
			defaultCourse = courseArray.get(i);

			tbA = (defaultCourse.getTextBooks());
			tbA.removeAll(Collections.singleton(null));
			if (tbA.isEmpty() == false) {

				String csv = "";
				for (int k = 0; k < tbA.size(); k++) {
					csv += tbA.get(k).getBookISBN() + ",";
				}

				ArrayList<String> tb = new ArrayList<String>(Arrays.asList(csv.split(",")));
				textBookArray = new ArrayList<TextBook>();
				for (int j = 0; j < tb.size(); j++) {
					textBookArray.add(textBookBag.searchByBookISBN(tb.get(j)));
				}
				
				defaultCourse.setTextBooks(textBookArray);
				courseBag.update(defaultCourse);
			}

		}

	}

	public void updateAllFaculty() {
		ArrayList<Faculty> fArray = facultyBag.getAllFaculty();
		fArray.removeAll(Collections.singleton(null));
		if (fArray.isEmpty() == false) {
			for (int i = 0; i < fArray.size(); i++) {
				defaultFaculty = fArray.get(i);

				String test = "";
				defaultFaculty.getCoursesTeaching().removeAll(Collections.singleton(null));
				for (int k = 0; k < defaultFaculty.getCoursesTeaching().size(); k++) {
					test += defaultFaculty.getCoursesTeaching().get(k).getCourseTitle() + ",";
				}
				ArrayList<String> course = new ArrayList<String>(Arrays.asList(test.split(",")));

				courseArray = new ArrayList<Course>();
				for (int j = 0; j < course.size(); j++) {
					courseArray.add(courseBag.searchByTittle(course.get(j)));
				}
				defaultFaculty.setCoursesTeaching(courseArray);
				facultyBag.update(defaultFaculty);

			}
		}

	}

	public void updateAllStudent() {
		ArrayList<Student> sArray = studentBag.getAllStudent();
		sArray.removeAll(Collections.singleton(null));
		if (sArray.isEmpty() == false) {
			String courseTook = "";
			String courseTaking = "";
			String coursesNeeded = "";

			for (int i = 0; i < sArray.size(); i++) {
				defaultStudent = sArray.get(i);
				defaultStudent.getCoursesTook().removeAll(Collections.singleton(null));
				for (int k = 0; k < defaultStudent.getCoursesTook().size(); k++) {
					courseTook += defaultStudent.getCoursesTook().get(k).getCourseTitle() + ",";
				}
				defaultStudent.getCoursesTaking().removeAll(Collections.singleton(null));
				for (int k = 0; k < defaultStudent.getCoursesTaking().size(); k++) {
					courseTaking += defaultStudent.getCoursesTaking().get(k).getCourseTitle() + ",";
				}
				defaultStudent.getCoursesNeeded().removeAll(Collections.singleton(null));
				for (int k = 0; k < defaultStudent.getCoursesNeeded().size(); k++) {
					coursesNeeded += defaultStudent.getCoursesNeeded().get(k).getCourseTitle() + ",";
				}

				ArrayList<String> courseTookArrayString = new ArrayList<String>(Arrays.asList(courseTook.split(",")));
				ArrayList<String> courseTakingArrayString = new ArrayList<String>(
						Arrays.asList(courseTaking.split(",")));
				ArrayList<String> courseNeededArrayString = new ArrayList<String>(
						Arrays.asList(coursesNeeded.split(",")));

				ArrayList<Course> courseTookArray = new ArrayList<Course>();
				ArrayList<Course> courseTakingArray = new ArrayList<Course>();
				ArrayList<Course> courseNeededArray = new ArrayList<Course>();

				for (int j = 0; j < courseTookArrayString.size(); j++) {
					courseTookArray.add(courseBag.searchByTittle(courseTookArrayString.get(j)));
				}

				for (int j = 0; j < courseTakingArrayString.size(); j++) {
					courseTakingArray.add(courseBag.searchByTittle(courseTakingArrayString.get(j)));
				}

				for (int j = 0; j < courseNeededArrayString.size(); j++) {
					courseNeededArray.add(courseBag.searchByTittle(courseNeededArrayString.get(j)));
				}
				defaultStudent.setCoursesTook(courseTookArray);
				defaultStudent.setCoursesTaking(courseTakingArray);
				defaultStudent.setCoursesNeeded(courseNeededArray);
				studentBag.update(defaultStudent);

			}

		}

	}

	private static boolean validatePhoneNumber(String phoneNo) {

		if (phoneNo.matches("\\d{3}[-]\\d{3}[-]\\d{4}"))
			return true;
		else
			return false;

	}

	public void clearAreas() {
		root.getTopPersonPane().getPersonFirstNameField().clear();
		root.getTopPersonPane().getPersonLastNameField().clear();
		root.getTopPersonPane().getPhoneNumberField().clear();
		root.getTopPersonPane().getAddressPane().getStreetNumberField().clear();
		root.getTopPersonPane().getAddressPane().getStreetNameField().clear();
		root.getTopPersonPane().getAddressPane().getCityField().clear();
		root.getTopPersonPane().getAddressPane().getStateField().clear();
		root.getTopPersonPane().getAddressPane().getZipCodeField().clear();
		root.getMiddleFacultyPane().getRankField().clear();
		root.getMiddleFacultyPane().getSalaryField().clear();
		root.getMiddleFacultyPane().getCoursesTeachingField().clear();
		root.getTopPersonPane().getPersonIDField().clear();
		root.getTopPersonPane().getIdSearchField().clear();
		root.getMiddleStudentPane().getCoursesNeededArea().clear();
		root.getMiddleStudentPane().getCreditsTakingField().clear();
		root.getMiddleStudentPane().getGpaField().clear();
		root.getTopPersonPane().getPersonIDField().clear();
	}

	private static boolean validateZipCode(String zipCode) {

		if (zipCode.matches("\\d{5}"))
			return true;
		else
			return false;

	}

}
