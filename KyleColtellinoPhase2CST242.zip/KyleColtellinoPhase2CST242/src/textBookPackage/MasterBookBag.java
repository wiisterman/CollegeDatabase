package textBookPackage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;


public class MasterBookBag  {
	ArrayList<TextBook> textBookArray = new ArrayList();

	public void add(TextBook s) {
		textBookArray.add(new TextBook(s.getBookTitle(), s.getBookISBN(), s.getBookAuthors(), s.getBookPrice()));
	}

	public TextBook searchByBookISBN(String isbn) {
		String found = "TextBook Not Found!";

		for (int i = 0; (i < textBookArray.size()); i++) {
			if (isbn.equals(textBookArray.get(i).getBookISBN())) {
				return textBookArray.get(i);
			}
		}

		return null;
	}

	public TextBook removeByBookISBN(String isbn) {
		int i = 0;
		for (TextBook s : textBookArray) {
			if (s.getBookISBN().equals(isbn)) {
				break;
			}
			i++;
		}
		if (i < textBookArray.size()) {
			return textBookArray.remove(i);
		}
		return null;

	}

	public String display() {
		String test = "";
		for (int i = 0; i < textBookArray.size(); i++) {
			test += ("\n"+textBookArray.get(i) + "\n");
		}

		return test;
	}

	public void update(TextBook txtBook) 
	{
	
		for (int i = 0; (i < textBookArray.size()); i++) {
			if (txtBook.getBookISBN().equals(textBookArray.get(i).getBookISBN())) {
				textBookArray.set(i, txtBook);
			}
		}		
	}
	public void save()
	{
		FileOutputStream fos;
		try {
			fos = new FileOutputStream("Data/Textbook.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(textBookArray);
			oos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	};
	
	public void load()
	{
		try {
			FileInputStream fis = new FileInputStream("Data/Textbook.txt");
			ObjectInputStream ois = new ObjectInputStream(fis);
			textBookArray = (ArrayList<TextBook>) ois.readObject();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("File Not Found: Textbook.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void exportTextBook(File file)
	{
		FileOutputStream fos;
		try {
			fos = new FileOutputStream(file);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(textBookArray);
			oos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	};
	
	public void importTextBook(File file)
	{
		try {
			FileInputStream fis = new FileInputStream(file);
			ObjectInputStream ois = new ObjectInputStream(fis);
			textBookArray = (ArrayList<TextBook>) ois.readObject();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("File Not Found: Textbook.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
