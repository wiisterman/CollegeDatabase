package textBookPackage;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

public class TextBookPane {
	private TextField textBookTitleField;
	private TextField textBookISBNField;
	private TextField textBookPriceField;
	private TextField authorFirstNameField;
	private TextField authorLastNameField;
	private TextField searchField;
	private TextArea bookInfoArea;
	private Button insertBtn;
	private Button searchBtn;
	private Button removeBtn;
	private Button updateBtn;
	private Button clearBtn;
	private Button displayBooksBtn;
	private Button addAuthorBtn;
	private Button saveBtn;
	private Label tbTitleLabel;
	private Label tbISBNLabel;
	private Label tbPriceLabel;
	private Label aFNLabel;
	private Label aLNLabel;
	private Label searchLbl;
	private Label progressLbl;
	private GridPane textBookPane;

	public TextBookPane() {
		textBookPane = new GridPane();
		textBookPane.setHgap(8);
		textBookPane.setVgap(8);

		textBookPane.setPadding(new Insets(20, 20, 20, 20));

		//
		bookInfoArea = new TextArea();
		bookInfoArea.setEditable(false);
		//
		textBookTitleField = new TextField();
		textBookISBNField = new TextField();
		textBookPriceField = new TextField();
		authorFirstNameField = new TextField();
		
		authorFirstNameField.setPromptText("Seperate By Comma");
		authorLastNameField = new TextField();
		authorLastNameField.setPromptText("Seperate By Comma");

		searchField = new TextField();
		searchField.setPromptText("ISBN");
		//
		insertBtn = new Button("Insert");
		searchBtn = new Button("Search");
		removeBtn = new Button("Remove");
		updateBtn = new Button("Update");
		clearBtn = new Button("Clear");
		displayBooksBtn = new Button("Display");
		saveBtn = new Button("Save");
		insertBtn.setPrefWidth(100);
		searchBtn.setPrefWidth(100);
		removeBtn.setPrefWidth(100);
		updateBtn.setPrefWidth(100);
		clearBtn.setPrefWidth(100);
		displayBooksBtn.setPrefWidth(100);
		saveBtn.setPrefWidth(100);
		textBookPane.setStyle("-fx-base:#abbace;");
		insertBtn.setStyle("-fx-base:#41f465;");
		removeBtn.setStyle("-fx-base:#ff6b6b;");
		searchBtn.setStyle("-fx-base:#ffffff;");
		updateBtn.setStyle("-fx-base:#ffffff;");
		clearBtn.setStyle("-fx-base:#ffffff;");
		displayBooksBtn.setStyle("-fx-base:#ffffff;");
		saveBtn.setStyle("-fx-base:#ffffff;");

		//
		tbTitleLabel = new Label("Title");
		tbISBNLabel = new Label("ISBN");
		tbPriceLabel = new Label("Price");
		aFNLabel = new Label("Author\nFirst Name");
		aLNLabel = new Label("Author\nLast Name");
		searchLbl = new Label("Search");
		progressLbl = new Label();
		// R0
		textBookPane.add(tbTitleLabel, 0, 0);
		textBookPane.add(textBookTitleField, 1, 0);
		// R1
		textBookPane.add(tbISBNLabel, 0, 1);
		textBookPane.add(textBookISBNField, 1, 1);
		// R2
		textBookPane.add(tbPriceLabel, 0, 2);
		textBookPane.add(textBookPriceField, 1, 2);
		// R3
		textBookPane.add(aFNLabel, 0, 3);
		textBookPane.add(authorFirstNameField, 1, 3);
		// R4
		textBookPane.add(aLNLabel, 0, 4);
		textBookPane.add(authorLastNameField, 1, 4);
		// textBookPane.add(addAuthorBtn, 2, 4);
		// R5
//		textBookPane.add(searchLbl, 0, 5);
//		textBookPane.add(searchField, 1, 5);
//		// R6
//		textBookPane.add(insertBtn, 0, 6);
//		textBookPane.add(searchBtn, 1, 6);
//		// R7
//		textBookPane.add(removeBtn, 0, 7);
//		textBookPane.add(updateBtn, 1, 7);
//		// R8
//		textBookPane.add(displayBooksBtn, 0, 8);
//		textBookPane.add(clearBtn, 1, 8);
//		// R9
//		textBookPane.add(saveBtn, 0, 9);
//		// Extra
//		bookInfoArea.setPrefWidth(250);
//		textBookPane.add(bookInfoArea, 3, 0, 3, 10);
		textBookPane.setAlignment(Pos.CENTER);
		textBookPane.setStyle("-fx-background-color:#f4aa42");
	}

	public TextField getTextBookTitleField() {
		return textBookTitleField;
	}

	public TextField getTextBookISBNField() {
		return textBookISBNField;
	}

	public TextField getTextBookPriceField() {
		return textBookPriceField;
	}

	public TextField getAuthorFirstNameField() {
		return authorFirstNameField;
	}

	public TextField getAuthorLastNameField() {
		return authorLastNameField;
	}

	public TextField getSearchField() {
		return searchField;
	}

	public Button getInsertBtn() {
		return insertBtn;
	}

	public Button getSearchBtn() {
		return searchBtn;
	}

	public Button getRemoveBtn() {
		return removeBtn;
	}

	public Button getUpdateBtn() {
		return updateBtn;
	}

	public Button getClearBtn() {
		return clearBtn;
	}

	public Button getDisplayBooksBtn() {
		return displayBooksBtn;
	}

	public Button getAddAuthorBtn() {
		return addAuthorBtn;
	}

	public Button getSaveBtn() {
		return saveBtn;
	}

	public Label getTbTitleLabel() {
		return tbTitleLabel;
	}

	public Label getTbISBNLabel() {
		return tbISBNLabel;
	}

	public Label getTbPriceLabel() {
		return tbPriceLabel;
	}

	public Label getaFNLabel() {
		return aFNLabel;
	}

	public Label getaLNLabel() {
		return aLNLabel;
	}

	public Label getSearchLbl() {
		return searchLbl;
	}

	public Label getProgressLbl() {
		return progressLbl;
	}

	public GridPane getTextBookPane() {
		return textBookPane;
	}

	public void setTextBookTitleField(String textBookTitleField) {
		this.textBookTitleField.setText(textBookTitleField);
	}

	public void setTextBookISBNField(String textBookISBNField) {
		this.textBookISBNField.setText(textBookISBNField);
	}

	public void setTextBookPriceField(String textBookPriceField) {
		this.textBookPriceField.setText(textBookPriceField);
	}

	public void setAuthorFirstNameField(String authorFirstNameField) {
		this.authorFirstNameField.setText(authorFirstNameField);
	}

	public void setAuthorLastNameField(String authorLastNameField) {
		this.authorLastNameField.setText(authorLastNameField);
	}

	public void setSearchField(String searchField) {
		this.searchField.setText(searchField);
	}

	public void setInsertBtn(Button insertBtn) {
		this.insertBtn = insertBtn;
	}

	public void setSearchBtn(Button searchBtn) {
		this.searchBtn = searchBtn;
	}

	public void setRemoveBtn(Button removeBtn) {
		this.removeBtn = removeBtn;
	}

	public void setUpdateBtn(Button updateBtn) {
		this.updateBtn = updateBtn;
	}

	public void setClearBtn(Button clearBtn) {
		this.clearBtn = clearBtn;
	}

	public void setDisplayBooksBtn(Button displayBooksBtn) {
		this.displayBooksBtn = displayBooksBtn;
	}

	public void setAddAuthorBtn(Button addAuthorBtn) {
		this.addAuthorBtn = addAuthorBtn;
	}

	public void setSaveBtn(Button saveBtn) {
		this.saveBtn = saveBtn;
	}

	public void setTbTitleLabel(Label tbTitleLabel) {
		this.tbTitleLabel = tbTitleLabel;
	}

	public void setTbISBNLabel(Label tbISBNLabel) {
		this.tbISBNLabel = tbISBNLabel;
	}

	public void setTbPriceLabel(Label tbPriceLabel) {
		this.tbPriceLabel = tbPriceLabel;
	}

	public void setaFNLabel(Label aFNLabel) {
		this.aFNLabel = aFNLabel;
	}

	public void setaLNLabel(Label aLNLabel) {
		this.aLNLabel = aLNLabel;
	}

	public void setSearchLbl(Label searchLbl) {
		this.searchLbl = searchLbl;
	}

	public void setProgressLbl(Label progressLbl) {
		this.progressLbl = progressLbl;
	}

	public void setTextBookPane(GridPane textBookPane) {
		this.textBookPane = textBookPane;
	}

	public TextArea getBookInfoArea() {
		return bookInfoArea;
	}

	public void setBookInfoArea(String bookInfoArea) {
		this.bookInfoArea.setText(bookInfoArea);
	}
}
