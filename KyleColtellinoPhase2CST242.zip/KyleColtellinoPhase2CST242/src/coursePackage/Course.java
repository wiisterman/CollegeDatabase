package coursePackage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

import textBookPackage.TextBook;



public class Course implements Serializable
{

	private String courseNumber;
	private String courseTitle;
	private String courseDescription;
	private double courseCredits;
	private ArrayList<TextBook> textBooks;
	
	private static int uniqueCourseNumber = 0;
	
	
	public Course( String courseTitle, String courseDescription, double courseCredits,
			ArrayList<TextBook> textBooks) {
		super();
		//this.courseNumber = courseNumber;
		this.courseTitle = courseTitle;
		this.courseDescription = courseDescription;
		this.courseCredits = courseCredits;
		this.textBooks = textBooks;
		File idFile = new File("courseNum.txt");
		try {
			Scanner input = new Scanner(idFile);
			uniqueCourseNumber = input.nextInt();

		} catch (FileNotFoundException e1) {

		}

		this.courseNumber = String.valueOf(uniqueCourseNumber++);

		for (int j = courseNumber.length(); j < 8; j++) {
			if (j == 7) {
				courseNumber = "SCCC" + courseNumber;
				break;
			}
			courseNumber = "0" + courseNumber;
		}

		PrintWriter pw;
		try {
			pw = new PrintWriter("courseNum.txt");
			pw.print(uniqueCourseNumber);
			pw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public String getCourseNumber() {
		return courseNumber;
	}
	public String getCourseTitle() {
		return courseTitle;
	}
	public void setCourseTitle(String courseTitle) {
		this.courseTitle = courseTitle;
	}
	public String getCourseDescription() {
		return courseDescription;
	}
	public void setCourseDescription(String courseDescription) {
		this.courseDescription = courseDescription;
	}
	public double getCourseCredits() {
		return courseCredits;
	}
	public void setCourseCredits(double courseCredits) {
		this.courseCredits = courseCredits;
	}
	public ArrayList<TextBook> getTextBooks() {
		return textBooks;
	}
	public void setTextBooks(ArrayList<TextBook> textBooks) {
		this.textBooks = textBooks;
	}
	@Override
	public String toString() {
		return "\n[Course]\nCourse Number: " + courseNumber + "\nCourse Title: " + courseTitle + "\nCourse Description: "
				+ courseDescription + "\nCourse Credits: " + courseCredits + "\nText Books: \n////\n" + textBooks.toString() + "\n";
	}
	
	
}
