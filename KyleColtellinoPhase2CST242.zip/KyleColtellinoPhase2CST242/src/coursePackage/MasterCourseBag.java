package coursePackage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class MasterCourseBag implements Serializable {
	ArrayList<Course> courseArray = new ArrayList();

	public void add(Course s) {
		courseArray.add(s);
	}

	public Course search(String cn) {

		if (cn != "") {
			for (int i = 0; (i < courseArray.size()); i++) {
				if (cn.equals(courseArray.get(i).getCourseNumber())) {
					return courseArray.get(i);
				}
			}
		}

		return null;
	}

	public Course searchByTittle(String cn) {
		String found = "TextBook Not Found!";

		for (int i = 0; (i < courseArray.size()); i++) {
			if (cn.equals(courseArray.get(i).getCourseTitle())) {
				return courseArray.get(i);
			}
		}

		return null;
	}

	public Course remove(String cn) {
		int i = 0;
		for (Course s : courseArray) {
			if (s.getCourseNumber().equals(cn)) {
				break;
			}
			i++;
		}
		if (i < courseArray.size()) {
			return courseArray.remove(i);
		}
		return null;

	}

	public String display() {
		String test = "";
		for (int i = 0; i < courseArray.size(); i++) {
			test += ("\n" + courseArray.get(i) + "\n");
		}

		return test;
	}

	public void update(Course c1) {

		for (int i = 0; (i < courseArray.size()); i++) {
			if (c1.getCourseNumber().equals(courseArray.get(i).getCourseNumber())) {
				courseArray.set(i, c1);
			}
		}

	}

	public void save() {
		FileOutputStream fos;
		try {
			fos = new FileOutputStream("Data/Course.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(courseArray);
			oos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	};

	public void load() {
		try {
			FileInputStream fis = new FileInputStream("Data/Course.txt");
			ObjectInputStream ois = new ObjectInputStream(fis);
			courseArray = (ArrayList<Course>) ois.readObject();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("File Not Found: Course.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void exportCourse(File file) {
		FileOutputStream fos;
		try {
			fos = new FileOutputStream(file);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(courseArray);
			oos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	};

	public void importCourse(File file) {
		try {
			FileInputStream fis = new FileInputStream(file);
			ObjectInputStream ois = new ObjectInputStream(fis);
			courseArray = (ArrayList<Course>) ois.readObject();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("File Not Found: Course.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public int size() {
		return courseArray.size();
	}

	public String getCourse() {
		String test = "";
		for (int i = 0; i < courseArray.size(); i++) {
			test += (courseArray.get(i).getCourseTitle() + ",");
		}

		return test;
	}

	public String getCourseCRN() {
		String test = "";
		for (int i = 0; i < courseArray.size(); i++) {
			test += (courseArray.get(i).getCourseNumber() + ",");
		}

		return test;
	}

	public String getCourseTitleByCRN(String crn) {
		String found = "";

		for (int i = 0; (i < courseArray.size()); i++) {
			if (crn.equals(courseArray.get(i).getCourseNumber())) {
				return courseArray.get(i).getCourseTitle();
			}
		}

		return null;
	}

	public ArrayList<Course> get() {

		return courseArray;

	}
}
