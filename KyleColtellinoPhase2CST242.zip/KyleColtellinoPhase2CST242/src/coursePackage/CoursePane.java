package coursePackage;

import java.util.ArrayList;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import textBookPackage.TextBook;

public class CoursePane {
	MasterCourseBag courseBag;

	GridPane coursePane;
	private Course updatedCourse;
	ArrayList<TextBook> textBookArray;
	Label courseNumberLbl;
	Label courseTitleLbl;
	Label courseDescriptionLbl;
	Label courseCreditLbl;
	Label textBookLbl;
	Label searchLbl;

	TextField courseNumberField;

	TextField courseTitleField;
	TextArea courseDescriptionArea;
	TextField courseCreditField;
	TextArea textBookArea;

	TextArea displayArea;
	TextField searchField;
	Button insertBtn;
	Button removeBtn;
	Button updateBtn;
	Button searchBtn;
	Button saveBtn;
	Button displayBtn;
	Button clearFieldsBtn;
	Button clearTextAreaBtn;

	public CoursePane() {
		coursePane = new GridPane();
		coursePane.setVgap(8);
		coursePane.setHgap(8);
		coursePane.setPadding(new Insets(20, 20, 20, 20));

		// Labels
		courseNumberLbl = new Label("Course Number");
		courseTitleLbl = new Label("Course Title");
		courseDescriptionLbl = new Label("Course Description");
		courseCreditLbl = new Label("Credits");
		textBookLbl = new Label("Text Books");
		searchLbl = new Label("Search CRN");

		// TextFields
		courseNumberField = new TextField();
		courseNumberField.setEditable(false);
		courseNumberField.setPromptText("'SCCC0000000'");
		courseTitleField = new TextField();
		courseDescriptionArea = new TextArea();
		courseCreditField = new TextField();
		textBookArea = new TextArea();
		textBookArea.setPromptText("Seperate Text Book ISBN with a comma");
		displayArea = new TextArea();
		searchField = new TextField();

		searchField.setPromptText("CRN");
		courseNumberField.setPrefWidth(200);
		courseTitleField.setPrefWidth(200);
		courseDescriptionArea.setPrefWidth(200);
		courseCreditField.setPrefWidth(200);
		textBookArea.setPrefWidth(200);
		displayArea.setPrefWidth(200);
		displayArea.setEditable(false);

		// Buttons

		insertBtn = new Button("Insert");
		removeBtn = new Button("Remove");
		updateBtn = new Button("Update");
		searchBtn = new Button("Search");
		saveBtn = new Button("Save");
		displayBtn = new Button("Display");
		clearFieldsBtn = new Button("Clear Fields");
		clearTextAreaBtn = new Button("Clear Text Area");
		insertBtn.setPrefWidth(200);
		removeBtn.setPrefWidth(200);
		updateBtn.setPrefWidth(200);
		searchBtn.setPrefWidth(200);
		saveBtn.setPrefWidth(200);
		displayBtn.setPrefWidth(200);
		clearFieldsBtn.setPrefWidth(200);
		clearTextAreaBtn.setPrefWidth(200);

		// Styles
		coursePane.setStyle("-fx-background-color:#abcdef");
		insertBtn.setStyle("-fx-base:#00ff08;");
		removeBtn.setStyle("-fx-base:#ff0000;");

		courseNumberLbl.setFont(Font.font(null, FontWeight.BOLD, 12));
		courseTitleLbl.setFont(Font.font(null, FontWeight.BOLD, 12));
		courseDescriptionLbl.setFont(Font.font(null, FontWeight.BOLD, 12));
		courseCreditLbl.setFont(Font.font(null, FontWeight.BOLD, 12));
		textBookLbl.setFont(Font.font(null, FontWeight.BOLD, 12));
		searchLbl.setFont(Font.font(null, FontWeight.BOLD, 12));

		// Add to Pane
		coursePane.add(courseNumberLbl, 0, 0);
		coursePane.add(courseNumberField, 1, 0);
		//
		coursePane.add(courseTitleLbl, 0, 1);
		coursePane.add(courseTitleField, 1, 1);
		//
		coursePane.add(courseDescriptionLbl, 0, 2);
		coursePane.add(courseDescriptionArea, 1, 2);
		//
		coursePane.add(courseCreditLbl, 0, 3);
		coursePane.add(courseCreditField, 1, 3);
		//
		coursePane.add(textBookLbl, 0, 4);
		coursePane.add(textBookArea, 1, 4);
		//
//		coursePane.add(searchLbl, 0, 5);
//		coursePane.add(searchField, 1, 5);
//		//
//		coursePane.add(insertBtn, 0, 6);
//		coursePane.add(removeBtn, 1, 6);
//		//
//		coursePane.add(updateBtn, 0, 7);
//		coursePane.add(searchBtn, 1, 7);
//		//
//		coursePane.add(saveBtn, 0, 8);
//		coursePane.add(displayBtn, 1, 8);
//		//
//		coursePane.add(clearFieldsBtn, 0, 9);
//		coursePane.add(clearTextAreaBtn, 1, 9);
//		//
//		coursePane.add(displayArea, 0, 10, 2, 11);

		courseDescriptionArea.setPrefHeight(100);
		textBookArea.setPrefHeight(100);
		coursePane.setAlignment(Pos.CENTER);
		textBookArea.autosize();
	}

	public MasterCourseBag getCourseBag() {
		return courseBag;
	}

	public GridPane getCoursePane() {
		return coursePane;
	}

	public Course getUpdatedCourse() {
		return updatedCourse;
	}

	public ArrayList<TextBook> getTextBookArray() {
		return textBookArray;
	}

	public Label getCourseNumberLbl() {
		return courseNumberLbl;
	}

	public Label getCourseTitleLbl() {
		return courseTitleLbl;
	}

	public Label getCourseDescriptionLbl() {
		return courseDescriptionLbl;
	}

	public Label getCourseCreditLbl() {
		return courseCreditLbl;
	}

	public Label getTextBookLbl() {
		return textBookLbl;
	}

	public Label getSearchLbl() {
		return searchLbl;
	}

	public TextField getCourseNumberField() {
		return courseNumberField;
	}

	public TextField getCourseTitleField() {
		return courseTitleField;
	}

	public TextArea getCourseDescriptionArea() {
		return courseDescriptionArea;
	}

	public TextField getCourseCreditField() {
		return courseCreditField;
	}

	public TextArea getTextBookArea() {
		return textBookArea;
	}

	public TextArea getDisplayArea() {
		return displayArea;
	}

	public TextField getSearchField() {
		return searchField;
	}

	public Button getInsertBtn() {
		return insertBtn;
	}

	public Button getRemoveBtn() {
		return removeBtn;
	}

	public Button getUpdateBtn() {
		return updateBtn;
	}

	public Button getSearchBtn() {
		return searchBtn;
	}

	public Button getSaveBtn() {
		return saveBtn;
	}

	public Button getDisplayBtn() {
		return displayBtn;
	}

	public Button getClearFieldsBtn() {
		return clearFieldsBtn;
	}

	public Button getClearTextAreaBtn() {
		return clearTextAreaBtn;
	}

	public void setCourseBag(MasterCourseBag courseBag) {
		this.courseBag = courseBag;
	}

	public void setCoursePane(GridPane coursePane) {
		this.coursePane = coursePane;
	}

	public void setUpdatedCourse(Course updatedCourse) {
		this.updatedCourse = updatedCourse;
	}

	public void setTextBookArray(ArrayList<TextBook> textBookArray) {
		this.textBookArray = textBookArray;
	}

	public void setCourseNumberLbl(Label courseNumberLbl) {
		this.courseNumberLbl = courseNumberLbl;
	}

	public void setCourseTitleLbl(Label courseTitleLbl) {
		this.courseTitleLbl = courseTitleLbl;
	}

	public void setCourseDescriptionLbl(Label courseDescriptionLbl) {
		this.courseDescriptionLbl = courseDescriptionLbl;
	}

	public void setCourseCreditLbl(Label courseCreditLbl) {
		this.courseCreditLbl = courseCreditLbl;
	}

	public void setTextBookLbl(Label textBookLbl) {
		this.textBookLbl = textBookLbl;
	}

	public void setSearchLbl(Label searchLbl) {
		this.searchLbl = searchLbl;
	}

	public void setCourseNumberField(TextField courseNumberField) {
		this.courseNumberField = courseNumberField;
	}

	public void setCourseTitleField(TextField courseTitleField) {
		this.courseTitleField = courseTitleField;
	}

	public void setCourseDescriptionArea(TextArea courseDescriptionArea) {
		this.courseDescriptionArea = courseDescriptionArea;
	}

	public void setCourseCreditField(TextField courseCreditField) {
		this.courseCreditField = courseCreditField;
	}

	public void setTextBookArea(TextArea textBookArea) {
		this.textBookArea = textBookArea;
	}

	public void setDisplayArea(TextArea displayArea) {
		this.displayArea = displayArea;
	}

	public void setSearchField(TextField searchField) {
		this.searchField = searchField;
	}

	public void setInsertBtn(Button insertBtn) {
		this.insertBtn = insertBtn;
	}

	public void setRemoveBtn(Button removeBtn) {
		this.removeBtn = removeBtn;
	}

	public void setUpdateBtn(Button updateBtn) {
		this.updateBtn = updateBtn;
	}

	public void setSearchBtn(Button searchBtn) {
		this.searchBtn = searchBtn;
	}

	public void setSaveBtn(Button saveBtn) {
		this.saveBtn = saveBtn;
	}

	public void setDisplayBtn(Button displayBtn) {
		this.displayBtn = displayBtn;
	}

	public void setClearFieldsBtn(Button clearFieldsBtn) {
		this.clearFieldsBtn = clearFieldsBtn;
	}

	public void setClearTextAreaBtn(Button clearTextAreaBtn) {
		this.clearTextAreaBtn = clearTextAreaBtn;
	}
}
