package coursePackage;

import java.util.ArrayList;
import java.util.Arrays;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.stage.Stage;
import textBookPackage.MasterBookBag;
import textBookPackage.TextBook;

public class CourseView extends Application {
	private MasterCourseBag courseBag;
	private ArrayList<TextBook> textBookArray;
	private MasterBookBag bookBag;
	private Course updatedCourse;
	String cTBString;
	@Override
	public void start(Stage primaryStage) throws Exception {
		
		CoursePane coursePane = new CoursePane();
		courseBag = new MasterCourseBag();
		bookBag = new MasterBookBag();
		courseBag.load();
		bookBag.load();
		coursePane.getInsertBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				String str = coursePane.getTextBookArea().getText();
				ArrayList<String> tb = new ArrayList<String>(Arrays.asList(str.split(",")));
				textBookArray = new ArrayList<TextBook>();
				for (int i = 0; i < tb.size(); i++) {
					textBookArray.add(bookBag.searchByBookISBN(tb.get(i)));
				}

				Course c1 = new Course(coursePane.getCourseTitleField().getText(), 
						coursePane.getCourseDescriptionArea().getText(),
						Double.parseDouble(coursePane.getCourseCreditField().getText()),
						textBookArray);
				courseBag.add(c1);
				coursePane.getCourseTitleField().clear();
				coursePane.getCourseDescriptionArea().clear();
				coursePane.getCourseCreditField().clear();
				coursePane.getTextBookArea().clear();

			}
		});
		
		coursePane.getSearchBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				cTBString = "";
				Course c = courseBag.search(coursePane.getSearchField().getText());
				if(c.getTextBooks().isEmpty())
				{
					for(int i = 0; i < c.getTextBooks().size();i++)
					{
						cTBString += c.getTextBooks().get(i).getBookISBN()+",";
					}
				}
				coursePane.getCourseNumberField().setText(c.getCourseNumber());
				coursePane.getCourseTitleField().setText(c.getCourseTitle());
				coursePane.getCourseDescriptionArea().setText(c.getCourseDescription());
				coursePane.getCourseCreditField().setText(String.valueOf(c.getCourseCredits()));
				coursePane.getTextBookArea().setText(cTBString);
			}
		});
		
		coursePane.getUpdateBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				
				String str = coursePane.getTextBookArea().getText();
				ArrayList<String> tb = new ArrayList<String>(Arrays.asList(str.split(",")));
				textBookArray = new ArrayList<TextBook>();
				for(int i = 0; i < tb.size();i++)
				{
					textBookArray.add(bookBag.searchByBookISBN(tb.get(i)));
				}
				
				updatedCourse = courseBag.search(coursePane.getSearchField().getText());
				updatedCourse.setCourseTitle(coursePane.getCourseTitleField().getText());
				updatedCourse.setCourseDescription(coursePane.getCourseDescriptionArea().getText());
				updatedCourse.setCourseCredits(Double.parseDouble(coursePane.getCourseCreditField().getText()));
				updatedCourse.setTextBooks(textBookArray);
				courseBag.update(updatedCourse);
			}

		});
		
		coursePane.getDisplayBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				coursePane.getDisplayArea().setText(courseBag.display());
			}
		});
		
		coursePane.getClearFieldsBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				coursePane.getCourseNumberField().clear();
				coursePane.getCourseTitleField().clear();
				coursePane.getCourseDescriptionArea().clear();
				coursePane.getCourseCreditField().clear();
				coursePane.getTextBookArea().clear();
				coursePane.getSearchField().clear();
			}
		});

		coursePane.getClearTextAreaBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				coursePane.getDisplayArea().clear();
			}
		});

		coursePane.getRemoveBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				courseBag.remove(coursePane.getSearchField().getText());
			}
		});
		
		coursePane.getSaveBtn().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				courseBag.save();
			}
		});
		

		Scene scene = new Scene(coursePane.getCoursePane());
		primaryStage.setScene(scene);
		primaryStage.show();

	}

	public static void main(String[] args) {
		Application.launch(args);
	}
}
